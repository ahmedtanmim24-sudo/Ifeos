import { db, TABLES } from './db'

const pad = (n: number) => String(n).padStart(2, '0')
export const ymd = (d: Date = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
export const today = () => ymd()
export const parse = (s: string) => new Date(s + 'T00:00:00')
export const addDays = (s: string, n: number) => { const d = parse(s); d.setDate(d.getDate() + n); return ymd(d) }
export const monthOf = (s: string) => s.slice(0, 7)
export const addMonths = (m: string, n: number) => { const d = new Date(m + '-01T00:00:00'); d.setMonth(d.getMonth() + n); return ymd(d).slice(0, 7) }
export const monthLabel = (m: string) => new Date(m + '-01T00:00:00').toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })
export const dateLabel = (s: string) => parse(s).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })
export const longDate = (d = new Date()) => d.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
export const dow = (s: string) => parse(s).getDay()
export const daysBetween = (a: string, b: string) => Math.round((parse(b).getTime() - parse(a).getTime()) / 86400000)
export const weekStart = (s: string) => addDays(s, -((dow(s) + 6) % 7)) // Monday
export const lastDays = (n: number, end = today()) => Array.from({ length: n }, (_, i) => addDays(end, i - n + 1))

export const money = (n: number, cur = '৳') => {
  const neg = n < 0
  const v = Math.abs(n).toLocaleString('en-US', { maximumFractionDigits: 2 })
  return `${neg ? '-' : ''}${cur}${v}`
}
export const hm = (min: number) => { const m = Math.round(min); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m` }
export const pct = (a: number, b: number) => (b > 0 ? Math.min(100, Math.round((a / b) * 100)) : 0)
export const uid = () => Math.random().toString(36).slice(2, 10)
export const num = (v: string) => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0 }

export function sleepMinutes(bed: string, wake: string) {
  const [bh, bm] = bed.split(':').map(Number)
  const [wh, wm] = wake.split(':').map(Number)
  let d = wh * 60 + wm - (bh * 60 + bm)
  if (d <= 0) d += 1440
  return d
}
export const REVISION_GAPS = [1, 3, 7, 14, 30]

export const EXPENSE_CATS = ['Food', 'Transport', 'Education', 'Hostel', 'Shopping', 'Healthcare', 'Family', 'Bills', 'Entertainment', 'Other']
export const INCOME_CATS = ['Allowance', 'Family support', 'Scholarship', 'Salary', 'Gift', 'Other']
export const METHODS = ['Cash', 'bKash', 'Nagad', 'Rocket', 'Bank', 'Card', 'Other']
export const CHART_COLORS = ['#2dd4a8', '#60a5fa', '#f59e0b', '#f472b6', '#a78bfa', '#34d399', '#fb7185', '#38bdf8', '#facc15', '#94a3b8']

/* ---------- Backup / restore ---------- */
export const BACKUP_APP = 'LIFE OS'

export async function buildBackup() {
  const data: Record<string, unknown[]> = {}
  for (const t of TABLES) data[t] = await (db as any)[t].toArray()
  return { app: BACKUP_APP, schema: 1, exportedAt: new Date().toISOString(), data }
}

export function download(filename: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }))
  const a = document.createElement('a')
  a.href = url; a.download = filename
  document.body.appendChild(a); a.click(); a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}

/** Returns an error message, or null when the parsed file looks like a valid LIFE OS backup. */
export function validateBackup(obj: any): string | null {
  if (!obj || typeof obj !== 'object') return 'This file is not a LIFE OS backup.'
  if (obj.app !== BACKUP_APP) return 'This file was not created by LIFE OS.'
  if (typeof obj.schema !== 'number' || obj.schema > 1) return 'This backup comes from a newer version of LIFE OS. Update the app first.'
  if (!obj.data || typeof obj.data !== 'object') return 'The backup has no data section.'
  for (const t of TABLES) {
    const rows = obj.data[t]
    if (rows === undefined) continue
    if (!Array.isArray(rows)) return `The "${t}" section is damaged.`
    for (const r of rows) if (!r || typeof r !== 'object' || Array.isArray(r)) return `The "${t}" section contains an invalid row.`
  }
  for (const k of Object.keys(obj.data)) if (!(TABLES as readonly string[]).includes(k)) return `Unknown section "${k}" in backup.`
  const keyed: Record<string, string> = { settings: 'key', daily: 'date', prayers: 'date', reviews: 'month' }
  for (const [t, key] of Object.entries(keyed)) {
    for (const r of obj.data[t] ?? []) if (typeof r[key] !== 'string') return `The "${t}" section has a row without "${key}".`
  }
  return null
}

export async function restoreBackup(obj: any) {
  const err = validateBackup(obj)
  if (err) throw new Error(err)
  await db.transaction('rw', TABLES.map((t) => (db as any)[t]), async () => {
    for (const t of TABLES) {
      const table = (db as any)[t]
      await table.clear()
      const rows = obj.data[t] ?? []
      if (rows.length) await table.bulkAdd(rows)
    }
  })
}

export async function resetAll() {
  await db.transaction('rw', TABLES.map((t) => (db as any)[t]), async () => {
    for (const t of TABLES) await (db as any)[t].clear()
  })
  await db.subjects.bulkAdd([{ name: 'Anatomy' }, { name: 'Physiology' }, { name: 'Biochemistry' }])
}

const csvCell = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`
export async function transactionsCsv() {
  const rows = await db.transactions.orderBy('date').toArray()
  const head = ['Date', 'Type', 'Category', 'Amount', 'Payment method', 'Note']
  return [head, ...rows.map((r) => [r.date, r.type, r.category, r.amount, r.method, r.note])].map((r) => r.map(csvCell).join(',')).join('\r\n')
}

import { useEffect, useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Pencil, Trash2, Search } from 'lucide-react'
import { Bar, Btn, Card, Confirm, Empty, Fab, Field, IconBtn, Loading, Modal, MonthNav, PageHead, Stat, Tabs, useRun, useSettings, useTabParam, saveSettings } from './ui'
import { db, type Saving, type Txn } from './db'
import { CHART_COLORS, EXPENSE_CATS, INCOME_CATS, METHODS, addMonths, dateLabel, monthLabel, monthOf, money, num, pct, today } from './lib'
import { Bar as RBar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

export default function Taka() {
  const s = useSettings()
  const { tab, setTab, add, clearAdd } = useTabParam('overview')
  const [month, setMonth] = useState(monthOf(today()))
  const [form, setForm] = useState<Txn | null>(null)
  const txns = useLiveQuery(() => db.transactions.orderBy('date').reverse().toArray(), [])

  useEffect(() => {
    if (add === 'expense' || add === 'income') { setForm(blank(add)); clearAdd() }
  }, [add])

  if (!txns) return <Loading />
  const cats = (t: 'income' | 'expense') => [...(t === 'expense' ? EXPENSE_CATS : INCOME_CATS), ...s.customCategories.filter((c) => !(t === 'expense' ? EXPENSE_CATS : INCOME_CATS).includes(c))]

  return (
    <>
      <PageHead title="TakaTrack" sub="Money, budget and savings" />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'overview', label: 'Overview' }, { id: 'txns', label: 'Transactions' }, { id: 'budget', label: 'Budget' }, { id: 'savings', label: 'Savings' }]} />
      {(tab === 'overview' || tab === 'budget') && <MonthNav month={month} onChange={setMonth} label={monthLabel(month)} />}
      {tab === 'overview' && <Overview txns={txns} month={month} cur={s.currency} budget={s.monthlyBudget} />}
      {tab === 'txns' && <List txns={txns} cur={s.currency} cats={[...new Set([...cats('expense'), ...cats('income')])]} onEdit={setForm} />}
      {tab === 'budget' && <Budget txns={txns} month={month} cats={cats('expense')} />}
      {tab === 'savings' && <Savings txns={txns} month={month} cur={s.currency} />}
      {tab !== 'savings' && <Fab label="Add" onClick={() => setForm(blank('expense'))} />}
      {form && <TxnForm initial={form} cats={cats(form.type)} onType={(t) => setForm({ ...form, type: t, category: cats(t)[0] })} onClose={() => setForm(null)} />}
    </>
  )
}

const blank = (type: 'income' | 'expense'): Txn => ({ type, amount: 0, category: type === 'expense' ? 'Food' : 'Allowance', date: today(), method: 'Cash', note: '' })

function sums(txns: Txn[], month?: string) {
  let inc = 0, exp = 0
  for (const t of txns) { if (month && monthOf(t.date) !== month) continue; if (t.type === 'income') inc += t.amount; else exp += t.amount }
  return { inc, exp }
}

function Overview({ txns, month, cur, budget }: { txns: Txn[]; month: string; cur: string; budget: number }) {
  const m = sums(txns, month), all = sums(txns)
  const byCat = useMemo(() => {
    const map: Record<string, number> = {}
    for (const t of txns) if (t.type === 'expense' && monthOf(t.date) === month) map[t.category] = (map[t.category] || 0) + t.amount
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value)
  }, [txns, month])
  const trend = useMemo(() => Array.from({ length: 6 }, (_, i) => {
    const mm = addMonths(month, i - 5), x = sums(txns, mm)
    return { m: new Date(mm + '-01T00:00:00').toLocaleDateString('en-GB', { month: 'short' }), Income: x.inc, Expenses: x.exp }
  }), [txns, month])
  const remaining = budget - m.exp

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Income this month" value={money(m.inc, cur)} tone="good" />
        <Stat label="Expenses this month" value={money(m.exp, cur)} tone="bad" />
        <Stat label="Balance (all time)" value={money(all.inc - all.exp, cur)} tone={all.inc - all.exp < 0 ? 'bad' : undefined} />
        <Stat label={budget > 0 ? 'Budget left' : 'Net this month'} value={money(budget > 0 ? remaining : m.inc - m.exp, cur)} tone={(budget > 0 ? remaining : m.inc - m.exp) < 0 ? 'bad' : 'good'} />
      </div>
      {budget > 0 && <Card><div className="flex justify-between text-sm mb-2"><span>Monthly budget</span><span className="num text-mute">{money(m.exp, cur)} of {money(budget, cur)}</span></div><Bar value={m.exp} max={budget} color={m.exp > budget ? 'rgb(var(--bad))' : undefined} /></Card>}
      <Card>
        <h3 className="font-bold mb-3">Spending by category</h3>
        {byCat.length === 0 ? <Empty title="No expenses this month" text="Add an expense to see where your money goes." /> : (
          <>
            <div style={{ height: 190 }}>
              <ResponsiveContainer><PieChart>
                <Pie data={byCat} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} paddingAngle={2} stroke="none">
                  {byCat.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v: number) => money(v, cur)} contentStyle={{ background: 'rgb(var(--panel2))', border: '1px solid rgb(var(--line))', borderRadius: 12 }} />
              </PieChart></ResponsiveContainer>
            </div>
            <ul className="mt-2 space-y-1.5">
              {byCat.map((c, i) => (
                <li key={c.name} className="flex items-center gap-2 text-sm">
                  <span className="h-3 w-3 rounded-full" style={{ background: CHART_COLORS[i % CHART_COLORS.length] }} />
                  <span className="flex-1">{c.name}</span><span className="num text-mute">{pct(c.value, m.exp)}%</span><span className="num w-24 text-right">{money(c.value, cur)}</span>
                </li>
              ))}
            </ul>
          </>
        )}
      </Card>
      <Card>
        <h3 className="font-bold mb-3">Last 6 months</h3>
        <div style={{ height: 180 }}>
          <ResponsiveContainer><BarChart data={trend}>
            <XAxis dataKey="m" tick={{ fill: 'rgb(var(--mute))', fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis hide />
            <Tooltip formatter={(v: number) => money(v, cur)} cursor={{ fill: 'rgb(var(--panel2))' }} contentStyle={{ background: 'rgb(var(--panel2))', border: '1px solid rgb(var(--line))', borderRadius: 12 }} />
            <RBar dataKey="Income" fill="#2dd4a8" radius={[6, 6, 0, 0]} />
            <RBar dataKey="Expenses" fill="#f472b6" radius={[6, 6, 0, 0]} />
          </BarChart></ResponsiveContainer>
        </div>
      </Card>
    </div>
  )
}

function List({ txns, cur, cats, onEdit }: { txns: Txn[]; cur: string; cats: string[]; onEdit: (t: Txn) => void }) {
  const run = useRun()
  const [q, setQ] = useState(''), [type, setType] = useState(''), [cat, setCat] = useState(''), [del, setDel] = useState<Txn | null>(null)
  const rows = txns.filter((t) => (!type || t.type === type) && (!cat || t.category === cat) &&
    (!q || (t.note + t.category + t.method + t.amount).toLowerCase().includes(q.toLowerCase())))
  return (
    <div>
      <div className="relative mb-3"><Search size={18} className="absolute left-3 top-3.5 text-mute" /><input className="inp pl-10" placeholder="Search notes, category, amount" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      <div className="grid grid-cols-2 gap-3 mb-4">
        <select className="inp" aria-label="Type" value={type} onChange={(e) => setType(e.target.value)}><option value="">All types</option><option value="income">Income</option><option value="expense">Expense</option></select>
        <select className="inp" aria-label="Category" value={cat} onChange={(e) => setCat(e.target.value)}><option value="">All categories</option>{cats.map((c) => <option key={c}>{c}</option>)}</select>
      </div>
      {rows.length === 0 ? <Empty title={txns.length ? 'Nothing matches' : 'No transactions yet'} text={txns.length ? 'Try clearing the search or filters.' : 'Tap Add to record your first income or expense.'} /> : (
        <ul className="space-y-2">
          {rows.map((t) => (
            <li key={t.id} className="rounded-2xl border border-line bg-panel p-3 flex items-center gap-2">
              <div className="min-w-0 flex-1">
                <p className="font-semibold truncate">{t.category}{t.note ? <span className="text-mute font-normal"> · {t.note}</span> : null}</p>
                <p className="text-xs text-mute">{dateLabel(t.date)} · {t.method}</p>
              </div>
              <p className={`num font-bold ${t.type === 'income' ? 'text-good' : 'text-ink'}`}>{t.type === 'income' ? '+' : '-'}{money(t.amount, cur)}</p>
              <IconBtn label="Edit" onClick={() => onEdit(t)}><Pencil size={18} /></IconBtn>
              <IconBtn label="Delete" tone="bad" onClick={() => setDel(t)}><Trash2 size={18} /></IconBtn>
            </li>
          ))}
        </ul>
      )}
      {del && <Confirm text={`Delete this ${del.type} of ${money(del.amount, cur)}?`} onNo={() => setDel(null)} onYes={async () => { await run(() => db.transactions.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}

function TxnForm({ initial, cats, onType, onClose }: { initial: Txn; cats: string[]; onType: (t: 'income' | 'expense') => void; onClose: () => void }) {
  const run = useRun()
  const [f, setF] = useState(initial)
  const [amt, setAmt] = useState(initial.amount ? String(initial.amount) : '')
  useEffect(() => setF((p) => ({ ...p, type: initial.type, category: initial.category })), [initial.type])
  const save = async () => {
    const amount = num(amt)
    if (amount <= 0) return alert('Enter an amount greater than zero.')
    const rec: Txn = { ...f, amount }
    const ok = await run(() => (f.id ? db.transactions.put(rec) : db.transactions.add(rec)), 'Saved')
    if (ok) onClose()
  }
  return (
    <Modal title={f.id ? 'Edit transaction' : 'Add transaction'} onClose={onClose}>
      <div className="grid grid-cols-2 gap-2 mb-4">
        {(['expense', 'income'] as const).map((t) => (
          <button key={t} type="button" onClick={() => onType(t)} className={`min-h-[44px] rounded-2xl font-semibold border ${f.type === t ? 'bg-accent text-on border-accent' : 'border-line text-mute'}`}>{t === 'expense' ? 'Expense' : 'Income'}</button>
        ))}
      </div>
      <Field label="Amount"><input className="inp num" inputMode="decimal" placeholder="0" value={amt} onChange={(e) => setAmt(e.target.value)} autoFocus /></Field>
      <Field label="Category"><select className="inp" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{cats.map((c) => <option key={c}>{c}</option>)}</select></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Date"><input type="date" className="inp" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value || today() })} /></Field>
        <Field label="Payment method"><select className="inp" value={f.method} onChange={(e) => setF({ ...f, method: e.target.value })}>{METHODS.map((c) => <option key={c}>{c}</option>)}</select></Field>
      </div>
      <Field label="Note (optional)"><input className="inp" value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></Field>
      <Btn full onClick={save}>Save</Btn>
    </Modal>
  )
}

function Budget({ txns, month, cats }: { txns: Txn[]; month: string; cats: string[] }) {
  const s = useSettings(), run = useRun()
  const [mb, setMb] = useState(String(s.monthlyBudget || '')), [cc, setCc] = useState('')
  useEffect(() => setMb(String(s.monthlyBudget || '')), [s.monthlyBudget])
  const spent: Record<string, number> = {}
  for (const t of txns) if (t.type === 'expense' && monthOf(t.date) === month) spent[t.category] = (spent[t.category] || 0) + t.amount
  return (
    <div className="space-y-4">
      <Card>
        <Field label={`Monthly budget (${s.currency})`} hint="Applies to every month. Leave empty or 0 for no budget.">
          <div className="flex gap-2"><input className="inp num" inputMode="decimal" value={mb} onChange={(e) => setMb(e.target.value)} /><Btn onClick={() => run(() => saveSettings({ monthlyBudget: num(mb) }), 'Budget saved')}>Save</Btn></div>
        </Field>
      </Card>
      <Card>
        <h3 className="font-bold mb-1">Category limits</h3>
        <p className="text-xs text-mute mb-3">Set a limit for any category. Progress shows {monthLabel(month)}.</p>
        <ul className="space-y-4">
          {cats.map((c) => <CatLimit key={c} cat={c} spent={spent[c] || 0} limit={s.categoryBudgets[c] || 0} cur={s.currency} />)}
        </ul>
      </Card>
      <Card>
        <h3 className="font-bold mb-3">Custom categories</h3>
        <div className="flex gap-2 mb-3"><input className="inp" placeholder="e.g. Books" value={cc} onChange={(e) => setCc(e.target.value)} />
          <Btn onClick={async () => { const n = cc.trim(); if (!n || cats.includes(n)) return; await run(() => saveSettings({ customCategories: [...s.customCategories, n] }), 'Category added'); setCc('') }}>Add</Btn></div>
        {s.customCategories.length === 0 ? <p className="text-sm text-mute">No custom categories yet.</p> : (
          <div className="flex flex-wrap gap-2">{s.customCategories.map((c) => (
            <button key={c} onClick={() => run(() => saveSettings({ customCategories: s.customCategories.filter((x) => x !== c) }), 'Removed (old transactions keep the name)')} className="rounded-full border border-line px-3 py-1.5 text-sm">{c} ✕</button>
          ))}</div>
        )}
      </Card>
    </div>
  )
}

function CatLimit({ cat, spent, limit, cur }: { cat: string; spent: number; limit: number; cur: string }) {
  const s = useSettings(), run = useRun()
  const [v, setV] = useState(limit ? String(limit) : '')
  useEffect(() => setV(limit ? String(limit) : ''), [limit])
  const commit = () => { const n = num(v); if (n === limit) return; const next = { ...s.categoryBudgets }; if (n > 0) next[cat] = n; else delete next[cat]; run(() => saveSettings({ categoryBudgets: next })) }
  return (
    <li>
      <div className="flex items-center gap-3 mb-1.5">
        <span className="flex-1 text-sm font-medium">{cat}</span>
        <span className="text-xs text-mute num">{money(spent, cur)}</span>
        <input className="inp !min-h-[40px] !w-28 num text-right" inputMode="decimal" placeholder="Limit" aria-label={`${cat} limit`} value={v} onChange={(e) => setV(e.target.value)} onBlur={commit} />
      </div>
      {limit > 0 && <Bar value={spent} max={limit} color={spent > limit ? 'rgb(var(--bad))' : undefined} h={6} />}
    </li>
  )
}

function Savings({ txns, month, cur }: { txns: Txn[]; month: string; cur: string }) {
  const goals = useLiveQuery(() => db.savings.toArray(), [])
  const run = useRun()
  const [edit, setEdit] = useState<Saving | null>(null), [dep, setDep] = useState<Saving | null>(null), [del, setDel] = useState<Saving | null>(null)
  const m = sums(txns, month), net = m.inc - m.exp
  if (!goals) return <Loading />
  return (
    <div className="space-y-4">
      <Card>
        <p className="text-sm text-mute">Saved from {monthLabel(month)} (income minus expenses)</p>
        <p className={`text-2xl font-extrabold num ${net < 0 ? 'text-bad' : 'text-good'}`}>{money(net, cur)}</p>
        {m.inc > 0 && <p className="text-sm text-mute mt-1">Savings rate {Math.round((net / m.inc) * 100)}%</p>}
      </Card>
      <div className="flex items-center justify-between"><h3 className="font-bold">Savings goals</h3><Btn small onClick={() => setEdit({ name: '', target: 0, saved: 0 })}>New goal</Btn></div>
      <p className="text-xs text-mute -mt-2">Goals are tracked on their own. Deposits here do not change your transaction balance.</p>
      {goals.length === 0 ? <Empty title="No savings goals yet" text="Set a target, like a laptop or an emergency fund." /> : goals.map((g) => (
        <Card key={g.id}>
          <div className="flex items-center justify-between gap-2">
            <p className="font-semibold">{g.name}</p>
            <div className="flex"><IconBtn label="Edit" onClick={() => setEdit(g)}><Pencil size={18} /></IconBtn><IconBtn label="Delete" tone="bad" onClick={() => setDel(g)}><Trash2 size={18} /></IconBtn></div>
          </div>
          <div className="flex justify-between text-sm my-2 num"><span>{money(g.saved, cur)}</span><span className="text-mute">of {money(g.target, cur)} · {pct(g.saved, g.target)}%</span></div>
          <Bar value={g.saved} max={g.target} />
          <Btn small variant="soft" className="mt-3" onClick={() => setDep(g)}>Add or remove money</Btn>
        </Card>
      ))}
      {edit && <GoalForm g={edit} onClose={() => setEdit(null)} />}
      {dep && <Deposit g={dep} onClose={() => setDep(null)} />}
      {del && <Confirm text={`Delete the goal "${del.name}"?`} onNo={() => setDel(null)} onYes={async () => { await run(() => db.savings.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}
function GoalForm({ g, onClose }: { g: Saving; onClose: () => void }) {
  const run = useRun(), [name, setName] = useState(g.name), [t, setT] = useState(g.target ? String(g.target) : '')
  return (
    <Modal title={g.id ? 'Edit goal' : 'New savings goal'} onClose={onClose}>
      <Field label="Name"><input className="inp" value={name} onChange={(e) => setName(e.target.value)} autoFocus /></Field>
      <Field label="Target amount"><input className="inp num" inputMode="decimal" value={t} onChange={(e) => setT(e.target.value)} /></Field>
      <Btn full onClick={async () => { if (!name.trim() || num(t) <= 0) return alert('Enter a name and a target above zero.'); const ok = await run(() => (g.id ? db.savings.put({ ...g, name: name.trim(), target: num(t) }) : db.savings.add({ name: name.trim(), target: num(t), saved: 0 })), 'Saved'); if (ok) onClose() }}>Save</Btn>
    </Modal>
  )
}
function Deposit({ g, onClose }: { g: Saving; onClose: () => void }) {
  const run = useRun(), [v, setV] = useState('')
  const apply = async (sign: 1 | -1) => { const n = num(v); if (n <= 0) return; const ok = await run(() => db.savings.put({ ...g, saved: Math.max(0, g.saved + sign * n) }), 'Updated'); if (ok) onClose() }
  return (
    <Modal title={g.name} onClose={onClose}>
      <Field label="Amount"><input className="inp num" inputMode="decimal" value={v} onChange={(e) => setV(e.target.value)} autoFocus /></Field>
      <div className="flex gap-3"><Btn full variant="ghost" onClick={() => apply(-1)}>Remove</Btn><Btn full onClick={() => apply(1)}>Add</Btn></div>
    </Modal>
  )
}

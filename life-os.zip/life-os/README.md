# LIFE OS

One private dashboard for money (TakaTrack), study (MedTrack), fitness (FitTrack), habits (HabitTrack) and life (LifeTrack: goals, sleep, prayers, tasks, journal).
React + TypeScript + Vite + Tailwind + Dexie (IndexedDB) + Recharts + vite-plugin-pwa. No accounts, no servers, no analytics. Data stays in your browser.

> This ZIP is the **source code**. It becomes an installable app only after it is built and hosted on HTTPS (steps below). It has not been built or tested in a browser by its author, so expect to fix a small issue or two on first deploy.

## Phone-only deployment (about 15 minutes)

All files are in one flat folder on purpose, so GitHub's mobile upload can take them in one go.

1. **Extract the ZIP.** In "Files by Google" (or your file manager), long-press `life-os.zip`, choose Extract. Open the extracted folder.
2. **Create a free GitHub account** at github.com (Chrome). Verify your email.
3. **Create a repository.** Tap the + icon, choose New repository, name it `life-os`, keep it Public (or Private if your host supports it), and create it.
4. **Upload the files.** On the new repository page use the "uploading an existing file" link, or Add file > Upload files. Tap the upload area, open the extracted folder, **select all files** (do not upload the ZIP itself), confirm, wait for them to attach, then Commit changes. You should see `index.html`, `package.json`, `vite.config.ts`, `App.tsx`, and the icon files directly in the repository root, not inside another folder.
5. **Host it for free.** Sign in with GitHub at Vercel, Netlify, or Cloudflare Pages. Choose to import or add a new project from your GitHub repository `life-os`. These settings should be detected for you; if asked, use:
   - Framework: Vite
   - Build command: `npm run build`
   - Output directory: `dist`
   Start the deploy and wait for the build to finish. Button names change over time, so follow the host's "import a Git repository" flow.
6. **Open the public address** the host gives you (it starts with `https://`) in Chrome.
7. **Install.** In Chrome, open the three-dot menu and choose **Install app** (or Add to Home screen). Chrome may take a few seconds to offer it. Open LIFE OS from your home screen.
8. **Test offline.** With the app opened once while online, switch on airplane mode and reopen it. The screens and your saved data should load. Add an entry, close and reopen the app, and check it is still there.
9. **Back up.** Settings > Export backup (JSON). Save the file to Google Drive or send it to yourself.

### If the build fails
Open the failed deployment's build log, copy the first red error, and paste it back to Claude with the file name. Common first-deploy causes are a file uploaded into a subfolder or a missing file.

## Your data and privacy
- Data is stored only in this browser (IndexedDB) on this phone.
- **Clearing Chrome's site data, clearing storage, or uninstalling the app can erase it.** Export backups regularly.
- Settings has JSON backup/restore (validated, with a confirmation before replacing data), CSV export of transactions, and a two-step reset.
- Journal and prayer entries are private and never leave the device unless you export a backup file.

## Development (only if you ever use a computer)
```
npm install
npm run dev
npm run build
```

## Notes and known limitations
- Works offline after the first successful load. Updates need a connection; the app updates itself next time it is opened online.
- Pomodoro timer runs only while the app is open; a locked or backgrounded phone may pause it.
- No notifications or reminders. Prayer times are not calculated; you tick prayers and add your own notes.
- Nutrition numbers are your own estimates. Savings goals are tracked separately from transactions.
- MedTrack contains no syllabus. Anatomy, Physiology and Biochemistry are created as empty, editable subjects.
- Data is per browser and per device. There is no sync between devices.
- Hosted at the site root (`/`). Hosting under a sub-path (for example GitHub Pages project sites) needs `base` changed in `vite.config.ts`.

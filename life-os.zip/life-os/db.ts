import Dexie, { type Table } from 'dexie'

export type Settings = {
  key: 'main'
  name: string
  theme: 'dark' | 'light'
  currency: string
  monthlyBudget: number
  categoryBudgets: Record<string, number>
  customCategories: string[]
  studyTargetMin: number
  sleepTargetH: number
  calorieTarget: number
  proteinTarget: number
  waterTargetMl: number
  stepTarget: number
  targetWeight: number
  weeklyWorkoutTarget: number
}
export const DEFAULT_SETTINGS: Settings = {
  key: 'main', name: '', theme: 'dark', currency: '৳', monthlyBudget: 0, categoryBudgets: {},
  customCategories: [], studyTargetMin: 120, sleepTargetH: 8, calorieTarget: 2200, proteinTarget: 90,
  waterTargetMl: 2500, stepTarget: 8000, targetWeight: 0, weeklyWorkoutTarget: 3
}

export type Txn = { id?: number; type: 'income' | 'expense'; amount: number; category: string; date: string; method: string; note: string }
export type Saving = { id?: number; name: string; target: number; saved: number }
export type Subject = { id?: number; name: string }
export type Revision = { date: string; done: boolean }
export type Topic = {
  id?: number; subjectId: number; paper: string; chapter: string; title: string; subtopic: string
  status: 'todo' | 'doing' | 'done'; priority: 'high' | 'medium' | 'low'; notes: string; revisions: Revision[]; createdAt: string
}
export type Session = { id?: number; date: string; minutes: number; subjectId?: number; note: string }
export type Exam = { id?: number; name: string; date: string; subjectId?: number; notes: string }
export type PlanItem = { id?: number; date: string; text: string; done: boolean }
export type Weight = { id?: number; date: string; kg: number }
export type Meal = { id?: number; date: string; name: string; kcal: number; protein: number }
export type Daily = { date: string; waterMl: number; steps: number; activity: string }
export type Exercise = { name: string; sets: number; reps: number; weight: number }
export type Workout = { id?: number; date: string; name: string; completed: boolean; exercises: Exercise[] }
export type Habit = {
  id?: number; name: string; emoji: string; schedule: 'daily' | 'days' | 'weekly'
  days: number[]; weeklyTarget: number; createdAt: string
}
export type HabitLog = { id?: number; habitId: number; date: string }
export type GoalTask = { id: string; text: string; done: boolean }
export type Goal = { id?: number; title: string; notes: string; deadline: string; tasks: GoalTask[]; completed: boolean }
export type Sleep = { id?: number; date: string; bed: string; wake: string; minutes: number; note: string }
export type Prayer = { date: string; done: Record<string, boolean>; notes: Record<string, string> }
export type Task = { id?: number; title: string; priority: 'high' | 'medium' | 'low'; dueDate: string; done: boolean; doneAt?: string }
export type Entry = { id?: number; date: string; kind: 'journal' | 'gratitude' | 'reflection' | 'lesson'; text: string }
export type Review = { month: string; wins: string; challenges: string; lessons: string; nextFocus: string }

export const TABLES = [
  'settings', 'transactions', 'savings', 'subjects', 'topics', 'sessions', 'exams', 'plans', 'weights', 'meals',
  'daily', 'workouts', 'habits', 'habitLogs', 'goals', 'sleep', 'prayers', 'tasks', 'journal', 'reviews'
] as const

class LifeDB extends Dexie {
  settings!: Table<Settings, string>
  transactions!: Table<Txn, number>
  savings!: Table<Saving, number>
  subjects!: Table<Subject, number>
  topics!: Table<Topic, number>
  sessions!: Table<Session, number>
  exams!: Table<Exam, number>
  plans!: Table<PlanItem, number>
  weights!: Table<Weight, number>
  meals!: Table<Meal, number>
  daily!: Table<Daily, string>
  workouts!: Table<Workout, number>
  habits!: Table<Habit, number>
  habitLogs!: Table<HabitLog, number>
  goals!: Table<Goal, number>
  sleep!: Table<Sleep, number>
  prayers!: Table<Prayer, string>
  tasks!: Table<Task, number>
  journal!: Table<Entry, number>
  reviews!: Table<Review, string>

  constructor() {
    super('lifeos')
    // Version 1. When the schema changes later, add this.version(2).stores({...}).upgrade(...) below.
    this.version(1).stores({
      settings: 'key',
      transactions: '++id, date, type, category',
      savings: '++id',
      subjects: '++id',
      topics: '++id, subjectId, status',
      sessions: '++id, date',
      exams: '++id, date',
      plans: '++id, date',
      weights: '++id, date',
      meals: '++id, date',
      daily: 'date',
      workouts: '++id, date',
      habits: '++id',
      habitLogs: '++id, habitId, date',
      goals: '++id',
      sleep: '++id, date',
      prayers: 'date',
      tasks: '++id, dueDate, done',
      journal: '++id, date, kind',
      reviews: 'month'
    })
    // Subject names you asked for. They are editable and deletable in MedTrack. No syllabus is included.
    this.on('populate', () => {
      this.subjects.bulkAdd([{ name: 'Anatomy' }, { name: 'Physiology' }, { name: 'Biochemistry' }])
    })
  }
}
export const db = new LifeDB()

export async function saveSettings(patch: Partial<Settings>) {
  const cur = (await db.settings.get('main')) ?? DEFAULT_SETTINGS
  await db.settings.put({ ...cur, ...patch, key: 'main' })
}

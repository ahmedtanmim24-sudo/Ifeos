import fs from 'node:fs'
import { defineConfig, type Plugin } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

// The project keeps every file in one flat folder so it can be uploaded to GitHub from a phone.
// This plugin places the icons and offline page into the build output at the paths the app expects.
const ROOT_ASSETS: Record<string, string> = {
  'icon.svg': 'icon.svg',
  'offline.html': 'offline.html',
  'icons/icon-192.png': 'icon-192.png',
  'icons/icon-512.png': 'icon-512.png',
  'icons/maskable-512.png': 'icon-maskable-512.png'
}
function copyRootAssets(): Plugin {
  return {
    name: 'copy-root-assets',
    apply: 'build',
    generateBundle() {
      for (const [fileName, src] of Object.entries(ROOT_ASSETS)) {
        this.emitFile({ type: 'asset', fileName, source: fs.readFileSync(src) })
      }
    }
  }
}

export default defineConfig({
  base: '/',
  plugins: [
    react(),
    copyRootAssets(),
    VitePWA({
      registerType: 'autoUpdate',
      manifest: {
        name: 'LIFE OS',
        short_name: 'LIFE OS',
        description: 'Money, study, fitness, habits and life goals in one private, offline-first app.',
        theme_color: '#121413',
        background_color: '#121413',
        display: 'standalone',
        orientation: 'portrait',
        start_url: '/',
        scope: '/',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
        ]
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,svg,png,ico,webmanifest}'],
        navigateFallback: 'index.html',
        cleanupOutdatedCaches: true
      }
    })
  ],
  build: { chunkSizeWarningLimit: 1200 }
})

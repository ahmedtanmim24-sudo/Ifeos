const c = (v) => `rgb(var(--${v}) / <alpha-value>)`
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: c('bg'), panel: c('panel'), panel2: c('panel2'), line: c('line'),
        ink: c('ink'), mute: c('mute'), accent: c('accent'), on: c('on'),
        good: c('good'), warn: c('warn'), bad: c('bad')
      },
      fontFamily: { sans: ['"Avenir Next"', '"Segoe UI"', 'Roboto', 'system-ui', 'sans-serif'] },
      borderRadius: { xl2: '1.25rem' }
    }
  },
  plugins: []
}

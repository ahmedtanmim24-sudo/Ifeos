import { useEffect, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Pencil, Trash2 } from 'lucide-react'
import { Bar, Btn, Card, Check, Confirm, Empty, Fab, Field, IconBtn, Loading, Modal, MonthNav, PageHead, Stat, Tabs, useRun, useSettings, useTabParam } from './ui'
import { db, type Entry, type Goal, type Review, type Task } from './db'
import { addDays, dateLabel, daysBetween, hm, lastDays, monthLabel, pct, sleepMinutes, today, uid } from './lib'
import { Bar as RBar, BarChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

export const PRAYERS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'] as const
const PRAYER_NAME: Record<string, string> = { fajr: 'Fajr', dhuhr: 'Dhuhr', asr: 'Asr', maghrib: 'Maghrib', isha: 'Isha' }

export default function Life() {
  const { tab, setTab, add, clearAdd } = useTabParam('tasks')
  return (
    <>
      <PageHead title="LifeTrack" sub="Goals, sleep, prayers and growth. All private." />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'tasks', label: 'Tasks' }, { id: 'goals', label: 'Goals' }, { id: 'sleep', label: 'Sleep' }, { id: 'prayers', label: 'Prayers' }, { id: 'growth', label: 'Growth' }]} />
      {tab === 'tasks' && <Tasks autoAdd={add === '1'} clearAdd={clearAdd} />}
      {tab === 'goals' && <Goals />}
      {tab === 'sleep' && <SleepTab />}
      {tab === 'prayers' && <Prayers />}
      {tab === 'growth' && <Growth />}
    </>
  )
}

/* ---------- Tasks / productivity ---------- */
const PRI = { high: 0, medium: 1, low: 2 } as const
function Tasks({ autoAdd, clearAdd }: { autoAdd: boolean; clearAdd: () => void }) {
  const run = useRun(), t0 = today()
  const tasks = useLiveQuery(() => db.tasks.toArray(), [])
  const [view, setView] = useState('open'), [form, setForm] = useState<Task | null>(null), [del, setDel] = useState<Task | null>(null)
  const blank = (): Task => ({ title: '', priority: 'medium', dueDate: t0, done: false })
  useEffect(() => { if (autoAdd) { setForm(blank()); clearAdd() } }, [autoAdd])
  if (!tasks) return <Loading />
  const dueToday = tasks.filter((t) => t.dueDate === t0 || (t.done && t.doneAt === t0))
  const doneToday = tasks.filter((t) => t.done && t.doneAt === t0).length
  const open = tasks.filter((t) => !t.done).sort((a, b) => (a.dueDate || '9').localeCompare(b.dueDate || '9') || PRI[a.priority] - PRI[b.priority])
  const rows = view === 'done' ? tasks.filter((t) => t.done).sort((a, b) => (b.doneAt || '').localeCompare(a.doneAt || '')) : view === 'today' ? open.filter((t) => t.dueDate && t.dueDate <= t0) : open
  const toggle = (t: Task) => run(() => db.tasks.put({ ...t, done: !t.done, doneAt: !t.done ? t0 : undefined }))
  return (
    <div>
      <Card className="mb-4"><div className="grid grid-cols-3 gap-3 text-center"><Mini l="Done today" v={doneToday} /><Mini l="Due today" v={open.filter((t) => t.dueDate === t0).length} /><Mini l="Overdue" v={open.filter((t) => t.dueDate && t.dueDate < t0).length} warn /></div>
        <div className="mt-3"><Bar value={doneToday} max={Math.max(1, doneToday + open.filter((t) => t.dueDate && t.dueDate <= t0).length)} /></div></Card>
      <div className="flex gap-2 mb-3">{[['open', 'Open'], ['today', 'Due today'], ['done', 'Done']].map(([id, l]) => <button key={id} onClick={() => setView(id)} className={`min-h-[40px] px-4 rounded-full text-sm font-semibold border ${view === id ? 'bg-accent text-on border-accent' : 'border-line text-mute'}`}>{l}</button>)}</div>
      {rows.length === 0 ? <Empty title={view === 'done' ? 'Nothing completed yet' : 'No tasks here'} text={view === 'done' ? undefined : 'Tap Task to add something you want to get done.'} /> : (
        <ul className="space-y-2">{rows.map((t) => (
          <li key={t.id} className="rounded-2xl border border-line bg-panel p-3 flex items-center gap-3">
            <Check on={t.done} label={`Complete ${t.title}`} onClick={() => toggle(t)} />
            <div className="flex-1 min-w-0"><p className={`font-medium truncate ${t.done ? 'line-through text-mute' : ''}`}>{t.title}</p>
              <p className="text-xs text-mute"><span className={t.priority === 'high' ? 'text-bad' : t.priority === 'medium' ? 'text-warn' : ''}>{t.priority}</span>{t.dueDate ? ` · ${t.dueDate < t0 && !t.done ? 'overdue ' : 'due '}${dateLabel(t.dueDate)}` : ''}</p></div>
            <IconBtn label="Edit" onClick={() => setForm(t)}><Pencil size={18} /></IconBtn><IconBtn label="Delete" tone="bad" onClick={() => setDel(t)}><Trash2 size={18} /></IconBtn>
          </li>))}</ul>
      )}
      <Fab label="Task" onClick={() => setForm(blank())} />
      {form && <TaskForm t={form} onClose={() => setForm(null)} />}
      {del && <Confirm text={`Delete "${del.title}"?`} onNo={() => setDel(null)} onYes={async () => { await run(() => db.tasks.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}
const Mini = ({ l, v, warn }: { l: string; v: number; warn?: boolean }) => <div><p className={`text-2xl font-extrabold num ${warn && v > 0 ? 'text-warn' : ''}`}>{v}</p><p className="text-xs text-mute">{l}</p></div>
function TaskForm({ t, onClose }: { t: Task; onClose: () => void }) {
  const run = useRun(), [f, setF] = useState(t)
  return (
    <Modal title={f.id ? 'Edit task' : 'New task'} onClose={onClose}>
      <Field label="Task"><input className="inp" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} autoFocus /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Priority"><select className="inp" value={f.priority} onChange={(e) => setF({ ...f, priority: e.target.value as Task['priority'] })}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></Field>
        <Field label="Due date"><input type="date" className="inp" value={f.dueDate} onChange={(e) => setF({ ...f, dueDate: e.target.value })} /></Field>
      </div>
      <Btn full onClick={async () => { if (!f.title.trim()) return alert('Write the task first.'); const rec = { ...f, title: f.title.trim() }; if (await run(() => (f.id ? db.tasks.put(rec) : db.tasks.add(rec)), 'Saved')) onClose() }}>Save</Btn>
    </Modal>
  )
}

/* ---------- Goals ---------- */
function Goals() {
  const run = useRun(), t0 = today()
  const goals = useLiveQuery(() => db.goals.toArray(), [])
  const [form, setForm] = useState<Goal | null>(null), [del, setDel] = useState<Goal | null>(null), [nt, setNt] = useState<Record<number, string>>({})
  if (!goals) return <Loading />
  const progress = (g: Goal) => (g.completed ? 100 : g.tasks.length ? pct(g.tasks.filter((t) => t.done).length, g.tasks.length) : 0)
  const sorted = [...goals].sort((a, b) => Number(a.completed) - Number(b.completed) || (a.deadline || '9').localeCompare(b.deadline || '9'))
  return (
    <div className="space-y-3">
      {sorted.length === 0 && <Empty title="No goals yet" text="Write a goal, give it a deadline, and break it into small tasks." action={<Btn onClick={() => setForm({ title: '', notes: '', deadline: '', tasks: [], completed: false })}>Create a goal</Btn>} />}
      {sorted.map((g) => (
        <Card key={g.id} className={g.completed ? 'opacity-70' : ''}>
          <div className="flex items-start gap-2">
            <Check on={g.completed} label={`Mark ${g.title} completed`} onClick={() => run(() => db.goals.put({ ...g, completed: !g.completed }))} />
            <div className="flex-1 min-w-0"><p className={`font-semibold ${g.completed ? 'line-through' : ''}`}>{g.title}</p>
              {g.deadline && <p className="text-xs text-mute">{g.completed ? 'Deadline' : daysBetween(t0, g.deadline) < 0 ? 'Past deadline' : `${daysBetween(t0, g.deadline)} days left`} · {dateLabel(g.deadline)}</p>}
              {g.notes && <p className="text-sm text-mute mt-1">{g.notes}</p>}</div>
            <IconBtn label="Edit" onClick={() => setForm(g)}><Pencil size={18} /></IconBtn><IconBtn label="Delete" tone="bad" onClick={() => setDel(g)}><Trash2 size={18} /></IconBtn>
          </div>
          <div className="flex items-center gap-3 my-3"><Bar value={progress(g)} max={100} /><span className="num text-xs text-mute w-10 text-right">{progress(g)}%</span></div>
          <ul className="space-y-2">{g.tasks.map((t) => (
            <li key={t.id} className="flex items-center gap-3"><Check on={t.done} label={t.text} onClick={() => run(() => db.goals.put({ ...g, tasks: g.tasks.map((x) => (x.id === t.id ? { ...x, done: !x.done } : x)) }))} />
              <span className={`flex-1 text-sm ${t.done ? 'line-through text-mute' : ''}`}>{t.text}</span>
              <IconBtn label="Remove task" tone="bad" onClick={() => run(() => db.goals.put({ ...g, tasks: g.tasks.filter((x) => x.id !== t.id) }))}><Trash2 size={16} /></IconBtn></li>))}</ul>
          <form className="flex gap-2 mt-3" onSubmit={async (e) => { e.preventDefault(); const v = (nt[g.id!] || '').trim(); if (!v) return; await run(() => db.goals.put({ ...g, tasks: [...g.tasks, { id: uid(), text: v, done: false }] })); setNt({ ...nt, [g.id!]: '' }) }}>
            <input className="inp" placeholder="Add a small step" value={nt[g.id!] || ''} onChange={(e) => setNt({ ...nt, [g.id!]: e.target.value })} /><Btn type="submit" variant="soft">Add</Btn>
          </form>
        </Card>
      ))}
      {goals.length > 0 && <Fab label="Goal" onClick={() => setForm({ title: '', notes: '', deadline: '', tasks: [], completed: false })} />}
      {form && <GoalForm g={form} onClose={() => setForm(null)} />}
      {del && <Confirm text={`Delete the goal "${del.title}"?`} onNo={() => setDel(null)} onYes={async () => { await run(() => db.goals.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}
function GoalForm({ g, onClose }: { g: Goal; onClose: () => void }) {
  const run = useRun(), [f, setF] = useState(g)
  return (
    <Modal title={f.id ? 'Edit goal' : 'New goal'} onClose={onClose}>
      <Field label="Goal"><input className="inp" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} autoFocus /></Field>
      <Field label="Deadline (optional)"><input type="date" className="inp" value={f.deadline} onChange={(e) => setF({ ...f, deadline: e.target.value })} /></Field>
      <Field label="Notes (optional)"><textarea className="inp" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
      <Btn full onClick={async () => { if (!f.title.trim()) return alert('Write the goal first.'); const rec = { ...f, title: f.title.trim() }; if (await run(() => (f.id ? db.goals.put(rec) : db.goals.add(rec)), 'Saved')) onClose() }}>Save</Btn>
    </Modal>
  )
}

/* ---------- Sleep ---------- */
function SleepTab() {
  const s = useSettings(), run = useRun()
  const rows = useLiveQuery(() => db.sleep.orderBy('date').reverse().toArray(), [])
  const [bed, setBed] = useState('23:00'), [wake, setWake] = useState('06:00'), [date, setDate] = useState(today()), [note, setNote] = useState(''), [del, setDel] = useState<number | null>(null)
  if (!rows) return <Loading />
  const mins = sleepMinutes(bed, wake), target = s.sleepTargetH * 60
  const days = lastDays(14), perDay = days.map((d) => ({ d: d.slice(5), h: Math.round((rows.filter((r) => r.date === d).reduce((a, r) => a + r.minutes, 0) / 60) * 10) / 10 }))
  const recent = rows.filter((r) => r.date >= addDays(today(), -6)), avg = recent.length ? recent.reduce((a, r) => a + r.minutes, 0) / recent.length : 0
  const last = rows[0]
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3"><Stat label="Last sleep" value={last ? hm(last.minutes) : '-'} /><Stat label="7-day average" value={avg ? hm(avg) : '-'} /><Stat label="Target" value={`${s.sleepTargetH}h`} /></div>
      <Card>
        <h3 className="font-bold mb-3">Log sleep</h3>
        <div className="grid grid-cols-2 gap-3"><Field label="Bedtime"><input type="time" className="inp" value={bed} onChange={(e) => setBed(e.target.value)} /></Field><Field label="Wake-up"><input type="time" className="inp" value={wake} onChange={(e) => setWake(e.target.value)} /></Field></div>
        <div className="grid grid-cols-2 gap-3"><Field label="Wake-up date"><input type="date" className="inp" value={date} onChange={(e) => setDate(e.target.value || today())} /></Field><Field label="Note (optional)"><input className="inp" value={note} onChange={(e) => setNote(e.target.value)} /></Field></div>
        <p className="text-sm text-mute mb-3">Duration: <span className="font-bold text-ink num">{hm(mins)}</span> {mins >= target ? '· target met' : `· ${hm(target - mins)} under target`}</p>
        <Btn full onClick={async () => { if (!bed || !wake) return alert('Set both times.'); if (await run(() => db.sleep.add({ date, bed, wake, minutes: mins, note: note.trim() }), 'Sleep saved')) setNote('') }}>Save sleep</Btn>
      </Card>
      <Card><h3 className="font-bold mb-2">Last 14 days (hours)</h3><div style={{ height: 160 }}><ResponsiveContainer><BarChart data={perDay}><XAxis dataKey="d" tick={{ fill: 'rgb(var(--mute))', fontSize: 10 }} axisLine={false} tickLine={false} interval={1} /><YAxis hide domain={[0, 12]} /><Tooltip contentStyle={{ background: 'rgb(var(--panel2))', border: '1px solid rgb(var(--line))', borderRadius: 12 }} cursor={{ fill: 'rgb(var(--panel2))' }} /><ReferenceLine y={s.sleepTargetH} stroke="#f59e0b" strokeDasharray="4 4" /><RBar dataKey="h" name="Hours" fill="#2dd4a8" radius={[5, 5, 0, 0]} /></BarChart></ResponsiveContainer></div></Card>
      {rows.length === 0 ? <Empty title="No sleep logged" text="Log last night to start your history." /> : (
        <ul className="space-y-2">{rows.slice(0, 30).map((r) => <li key={r.id} className="rounded-2xl border border-line bg-panel p-3 flex items-center gap-2"><div className="flex-1 min-w-0"><p className="font-semibold num">{hm(r.minutes)}</p><p className="text-xs text-mute">{dateLabel(r.date)} · {r.bed} to {r.wake}{r.note ? ` · ${r.note}` : ''}</p></div><IconBtn label="Delete" tone="bad" onClick={() => setDel(r.id!)}><Trash2 size={18} /></IconBtn></li>)}</ul>
      )}
      {del !== null && <Confirm text="Delete this sleep entry?" onNo={() => setDel(null)} onYes={async () => { await run(() => db.sleep.delete(del), 'Deleted'); setDel(null) }} />}
    </div>
  )
}

/* ---------- Prayers ---------- */
export async function togglePrayer(date: string, key: string, cur?: { done: Record<string, boolean>; notes: Record<string, string> }) {
  const base = cur ?? { done: {}, notes: {} }
  await db.prayers.put({ date, done: { ...base.done, [key]: !base.done[key] }, notes: base.notes })
}
function Prayers() {
  const run = useRun(), [date, setDate] = useState(today())
  const week = lastDays(7)
  const rows = useLiveQuery(() => db.prayers.where('date').between(addDays(today(), -30), addDays(today(), 1)).toArray(), [])
  const [edit, setEdit] = useState<string | null>(null), [note, setNote] = useState('')
  if (!rows) return <Loading />
  const get = (d: string) => rows.find((r) => r.date === d)
  const count = (d: string) => PRAYERS.filter((k) => get(d)?.done[k]).length
  const cur = get(date), weekDone = week.reduce((a, d) => a + count(d), 0)
  return (
    <div className="space-y-4">
      <p className="text-sm text-mute">Private to this device. Prayer times are not calculated, so add your own notes if you like.</p>
      <div className="flex items-center gap-2"><Btn small variant="ghost" onClick={() => setDate(addDays(date, -1))}>‹</Btn><input type="date" className="inp text-center" value={date} max={today()} onChange={(e) => setDate(e.target.value || today())} /><Btn small variant="ghost" onClick={() => setDate(addDays(date, 1))} disabled={date >= today()}>›</Btn></div>
      <Card>
        <div className="flex justify-between mb-3"><h3 className="font-bold">{date === today() ? 'Today' : dateLabel(date)}</h3><span className="num text-sm text-mute">{count(date)} / 5</span></div>
        <ul className="space-y-3">{PRAYERS.map((k) => (
          <li key={k}><div className="flex items-center gap-3"><Check on={!!cur?.done[k]} label={`${PRAYER_NAME[k]} prayed`} onClick={() => run(() => togglePrayer(date, k, cur))} /><span className="flex-1 font-medium">{PRAYER_NAME[k]}{cur?.notes[k] ? <span className="text-mute font-normal text-sm"> · {cur.notes[k]}</span> : null}</span>
            <button className="text-xs text-accent min-h-[40px] px-2" onClick={() => { setEdit(k); setNote(cur?.notes[k] || '') }}>{cur?.notes[k] ? 'Edit note' : 'Add note'}</button></div></li>))}</ul>
      </Card>
      <Card>
        <div className="flex justify-between mb-3"><h3 className="font-bold">This week</h3><span className="num text-sm text-mute">{weekDone} / 35 · {pct(weekDone, 35)}%</span></div>
        <div className="grid grid-cols-7 gap-1.5">{week.map((d) => <button key={d} onClick={() => setDate(d)} className="text-center"><p className="text-[10px] text-mute mb-1">{new Date(d + 'T00:00:00').toLocaleDateString('en-GB', { weekday: 'short' })}</p><div className="grid gap-0.5">{PRAYERS.map((k) => <span key={k} className={`h-2.5 rounded-full ${get(d)?.done[k] ? 'bg-accent' : 'bg-panel2'}`} />)}</div></button>)}</div>
      </Card>
      {edit && <Modal title={`${PRAYER_NAME[edit]} note`} onClose={() => setEdit(null)}>
        <Field label="Your note (e.g. the time you prayed)"><input className="inp" value={note} onChange={(e) => setNote(e.target.value)} autoFocus /></Field>
        <Btn full onClick={async () => { const base = cur ?? { date, done: {}, notes: {} }; const notes = { ...base.notes }; if (note.trim()) notes[edit] = note.trim(); else delete notes[edit]; if (await run(() => db.prayers.put({ date, done: base.done, notes }), 'Saved')) setEdit(null) }}>Save</Btn>
      </Modal>}
    </div>
  )
}

/* ---------- Growth ---------- */
const KINDS: { id: Entry['kind']; label: string; ph: string }[] = [
  { id: 'journal', label: 'Journal', ph: 'What is on your mind?' }, { id: 'gratitude', label: 'Gratitude', ph: 'What are you grateful for?' },
  { id: 'reflection', label: 'Reflection', ph: 'How did today go?' }, { id: 'lesson', label: 'Lessons', ph: 'What did you learn?' }
]
function Growth() {
  const run = useRun()
  const [kind, setKind] = useState<Entry['kind'] | 'review'>('journal'), [text, setText] = useState(''), [edit, setEdit] = useState<Entry | null>(null), [del, setDel] = useState<Entry | null>(null)
  const entries = useLiveQuery(() => db.journal.orderBy('date').reverse().toArray(), [])
  if (!entries) return <Loading />
  const k = KINDS.find((x) => x.id === kind)
  return (
    <div>
      <p className="text-xs text-mute mb-3">Entries are stored only on this device. They are included in a backup file only if you export one.</p>
      <Tabs value={kind} onChange={(v) => setKind(v as typeof kind)} tabs={[...KINDS.map((x) => ({ id: x.id, label: x.label })), { id: 'review', label: 'Monthly review' }]} />
      {kind === 'review' ? <MonthlyReview /> : (
        <div className="space-y-4">
          <Card><textarea className="inp mb-3" placeholder={k?.ph} value={text} onChange={(e) => setText(e.target.value)} /><Btn full onClick={async () => { const v = text.trim(); if (!v) return; if (await run(() => db.journal.add({ date: today(), kind: kind as Entry['kind'], text: v }), 'Saved')) setText('') }}>Save entry</Btn></Card>
          {entries.filter((e) => e.kind === kind).length === 0 ? <Empty title="Nothing here yet" text="Write your first entry above." /> : (
            <ul className="space-y-2">{entries.filter((e) => e.kind === kind).map((e) => <li key={e.id} className="rounded-2xl border border-line bg-panel p-3"><div className="flex items-center"><p className="flex-1 text-xs text-mute">{dateLabel(e.date)}</p><IconBtn label="Edit" onClick={() => setEdit(e)}><Pencil size={16} /></IconBtn><IconBtn label="Delete" tone="bad" onClick={() => setDel(e)}><Trash2 size={16} /></IconBtn></div><p className="whitespace-pre-wrap">{e.text}</p></li>)}</ul>
          )}
        </div>
      )}
      {edit && <EditEntry e={edit} onClose={() => setEdit(null)} />}
      {del && <Confirm text="Delete this entry?" onNo={() => setDel(null)} onYes={async () => { await run(() => db.journal.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}
function EditEntry({ e, onClose }: { e: Entry; onClose: () => void }) {
  const run = useRun(), [t, setT] = useState(e.text)
  return <Modal title="Edit entry" onClose={onClose}><textarea className="inp mb-3" value={t} onChange={(x) => setT(x.target.value)} autoFocus /><Btn full onClick={async () => { if (!t.trim()) return; if (await run(() => db.journal.put({ ...e, text: t.trim() }), 'Saved')) onClose() }}>Save</Btn></Modal>
}
function MonthlyReview() {
  const run = useRun(), [month, setMonth] = useState(today().slice(0, 7))
  const rev = useLiveQuery(() => db.reviews.get(month).then((r) => ({ r })), [month])
  const [f, setF] = useState<Review>({ month, wins: '', challenges: '', lessons: '', nextFocus: '' })
  useEffect(() => { if (rev) setF(rev.r ?? { month, wins: '', challenges: '', lessons: '', nextFocus: '' }) }, [rev, month])
  if (!rev) return <Loading />
  const q: [keyof Review, string][] = [['wins', 'What went well this month?'], ['challenges', 'What was hard?'], ['lessons', 'What did you learn?'], ['nextFocus', 'What will you focus on next month?']]
  return (
    <div>
      <MonthNav month={month} onChange={setMonth} label={monthLabel(month)} />
      <Card>{q.map(([key, label]) => <Field key={key} label={label}><textarea className="inp" value={f[key]} onChange={(e) => setF({ ...f, [key]: e.target.value })} /></Field>)}
        <Btn full onClick={() => run(() => db.reviews.put({ ...f, month }), 'Review saved')}>Save review</Btn></Card>
    </div>
  )
}

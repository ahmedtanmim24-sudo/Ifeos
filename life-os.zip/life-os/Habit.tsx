import { useMemo, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Pencil, Trash2 } from 'lucide-react'
import { Bar, Btn, Card, Check, Confirm, Empty, Fab, Field, IconBtn, Loading, Modal, MonthNav, PageHead, Stat, Tabs, useRun, useTabParam } from './ui'
import { db, type Habit } from './db'
import { addDays, dow, lastDays, monthLabel, pct, today, weekStart, parse, ymd } from './lib'
import { Bar as RBar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

const SUGGESTED = [['📚', 'Study'], ['🏃', 'Exercise'], ['📖', 'Read'], ['💧', 'Drink enough water'], ['🌙', 'Sleep on time'], ['☀️', 'Get sunlight'], ['📵', 'Avoid unnecessary screen time']]
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

/** Weekly habits can be done on any day, so they count as "due" every day; the weekly target is checked per week. */
export const isDue = (h: Habit, date: string) => date >= h.createdAt && (h.schedule === 'days' ? h.days.includes(dow(date)) : true)

export function habitStats(h: Habit, done: Set<string>) {
  const t0 = today()
  const dueDays: string[] = []
  for (let d = h.createdAt; d <= t0; d = addDays(d, 1)) if (isDue(h, d)) dueDays.push(d)
  let cur = 0, best = 0, run = 0

  if (h.schedule === 'weekly') {
    const target = Math.max(1, h.weeklyTarget)
    const weeks: Record<string, number> = {}
    for (const d of done) if (d >= h.createdAt && d <= t0) { const w = weekStart(d); weeks[w] = (weeks[w] || 0) + 1 }
    const thisW = weekStart(t0)
    for (let w = weekStart(h.createdAt); w <= thisW; w = addDays(w, 7)) {
      if ((weeks[w] || 0) >= target) { run++; best = Math.max(best, run) } else if (w !== thisW) run = 0
    }
    cur = run
    const rate = (n: number) => { let a = 0, b = 0; for (let i = 0; i < n; i++) { const w = addDays(thisW, -7 * i); if (w < weekStart(h.createdAt)) break; b++; if ((weeks[w] || 0) >= target) a++ } return b ? Math.round((a / b) * 100) : 0 }
    return { cur, best, d7: rate(1), d30: rate(4), missed30: 0 }
  }

  for (const d of dueDays) { if (done.has(d)) { run++; best = Math.max(best, run) } else if (d !== t0) run = 0 }
  cur = run
  const win = (n: number) => { const from = addDays(t0, -(n - 1)); const ds = dueDays.filter((d) => d >= from); const dn = ds.filter((d) => done.has(d)).length; return { dn, total: ds.length, missed: ds.filter((d) => d !== t0 && !done.has(d)).length } }
  const a = win(7), b = win(30)
  return { cur, best, d7: a.total ? Math.round((a.dn / a.total) * 100) : 0, d30: b.total ? Math.round((b.dn / b.total) * 100) : 0, missed30: b.missed }
}

export default function HabitPage() {
  const { tab, setTab } = useTabParam('today')
  const habits = useLiveQuery(() => db.habits.toArray(), [])
  const logs = useLiveQuery(() => db.habitLogs.toArray(), [])
  const [form, setForm] = useState<Habit | null>(null)
  const byHabit = useMemo(() => { const m = new Map<number, Set<string>>(); for (const l of logs ?? []) { if (!m.has(l.habitId)) m.set(l.habitId, new Set()); m.get(l.habitId)!.add(l.date) } return m }, [logs])
  if (!habits || !logs) return <Loading />
  return (
    <>
      <PageHead title="HabitTrack" sub="Small steps. Restart any day." />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'today', label: 'Today' }, { id: 'calendar', label: 'Calendar' }, { id: 'stats', label: 'Stats' }, { id: 'manage', label: 'Manage' }]} />
      {tab === 'today' && <TodayList habits={habits} byHabit={byHabit} onNew={() => setForm(blank())} />}
      {tab === 'calendar' && <Calendar habits={habits} byHabit={byHabit} />}
      {tab === 'stats' && <Stats habits={habits} byHabit={byHabit} />}
      {tab === 'manage' && <Manage habits={habits} onEdit={setForm} />}
      <Fab label="Habit" onClick={() => setForm(blank())} />
      {form && <HabitForm h={form} onClose={() => setForm(null)} />}
    </>
  )
}
const blank = (): Habit => ({ name: '', emoji: '⭐', schedule: 'daily', days: [1, 2, 3, 4, 5], weeklyTarget: 3, createdAt: today() })

export function toggleHabit(h: Habit, date: string, logs: Set<string> | undefined) {
  if (logs?.has(date)) return db.habitLogs.where('habitId').equals(h.id!).and((l) => l.date === date).delete()
  return db.habitLogs.add({ habitId: h.id!, date })
}

function TodayList({ habits, byHabit, onNew }: { habits: Habit[]; byHabit: Map<number, Set<string>>; onNew: () => void }) {
  const run = useRun(), t0 = today()
  const due = habits.filter((h) => isDue(h, t0))
  const done = due.filter((h) => byHabit.get(h.id!)?.has(t0)).length
  if (habits.length === 0) return (
    <div>
      <Empty title="No habits yet" text="Pick a suggestion or create your own. You can change everything later." action={<Btn onClick={onNew}>Create a habit</Btn>} />
      <p className="text-sm text-mute mt-5 mb-2">Suggestions</p>
      <div className="flex flex-wrap gap-2">{SUGGESTED.map(([e, n]) => <button key={n} onClick={() => run(() => db.habits.add({ ...blank(), emoji: e, name: n }), 'Habit added')} className="rounded-full border border-line px-3 py-2 text-sm">{e} {n}</button>)}</div>
    </div>
  )
  const week = lastDays(7)
  return (
    <div className="space-y-3">
      <Card><div className="flex justify-between text-sm mb-2"><span>{done} of {due.length} done today</span><span className="num text-mute">{pct(done, due.length)}%</span></div><Bar value={done} max={due.length} />
        <p className="text-xs text-mute mt-2">{done === due.length && due.length > 0 ? 'All done. Nice work.' : 'Every check counts. A missed day never erases your progress.'}</p></Card>
      {due.map((h) => {
        const ds = byHabit.get(h.id!)
        return (
          <Card key={h.id}>
            <div className="flex items-center gap-3">
              <Check on={!!ds?.has(t0)} label={`Mark ${h.name} done`} onClick={() => run(() => toggleHabit(h, t0, ds))} />
              <div className="flex-1 min-w-0"><p className="font-semibold truncate">{h.emoji} {h.name}</p><p className="text-xs text-mute">{h.schedule === 'weekly' ? `${h.weeklyTarget}× per week` : h.schedule === 'days' ? h.days.map((d) => DAYS[d]).join(', ') : 'Every day'}</p></div>
            </div>
            <div className="flex gap-1.5 mt-3 pl-11">{week.map((d) => <button key={d} aria-label={`${d} ${ds?.has(d) ? 'done' : 'not done'}`} onClick={() => run(() => toggleHabit(h, d, ds))} className={`h-6 w-6 rounded-md text-[10px] ${ds?.has(d) ? 'bg-accent text-on' : isDue(h, d) ? 'bg-panel2 text-mute' : 'bg-transparent border border-line text-mute'}`}>{parse(d).getDate()}</button>)}</div>
          </Card>
        )
      })}
      {due.length === 0 && <Empty title="Nothing scheduled today" text="Enjoy the rest day." />}
    </div>
  )
}

function Calendar({ habits, byHabit }: { habits: Habit[]; byHabit: Map<number, Set<string>> }) {
  const [month, setMonth] = useState(today().slice(0, 7)), [hid, setHid] = useState(0)
  if (habits.length === 0) return <Empty title="No habits to show" text="Create a habit to see its calendar." />
  const first = parse(month + '-01'), start = (first.getDay() + 6) % 7, count = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate()
  const cells: (string | null)[] = [...Array(start).fill(null), ...Array.from({ length: count }, (_, i) => `${month}-${String(i + 1).padStart(2, '0')}`)]
  const level = (d: string) => {
    const list = hid ? habits.filter((h) => h.id === hid) : habits
    const due = list.filter((h) => isDue(h, d)); if (!due.length || d > today()) return -1
    return due.filter((h) => byHabit.get(h.id!)?.has(d)).length / due.length
  }
  return (
    <div>
      <MonthNav month={month} onChange={setMonth} label={monthLabel(month)} />
      <select className="inp mb-4" aria-label="Habit" value={hid} onChange={(e) => setHid(Number(e.target.value))}><option value={0}>All habits</option>{habits.map((h) => <option key={h.id} value={h.id}>{h.emoji} {h.name}</option>)}</select>
      <Card>
        <div className="grid grid-cols-7 gap-1.5 text-center text-xs text-mute mb-1.5">{['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => <span key={i}>{d}</span>)}</div>
        <div className="grid grid-cols-7 gap-1.5">{cells.map((d, i) => {
          if (!d) return <span key={i} />
          const l = level(d)
          return <div key={i} className={`aspect-square rounded-lg grid place-items-center text-xs num ${d === today() ? 'ring-2 ring-accent' : ''} ${l < 0 ? 'text-mute' : l === 0 ? 'bg-panel2 text-mute' : 'text-on'}`} style={l > 0 ? { background: `rgb(var(--accent) / ${0.35 + 0.65 * l})` } : undefined}>{parse(d).getDate()}</div>
        })}</div>
        <p className="text-xs text-mute mt-3">Brighter means more habits done that day. Empty days are just a fresh start.</p>
      </Card>
    </div>
  )
}

function Stats({ habits, byHabit }: { habits: Habit[]; byHabit: Map<number, Set<string>> }) {
  if (habits.length === 0) return <Empty title="No stats yet" text="Check off a habit and your streaks appear here." />
  const weeks = Array.from({ length: 8 }, (_, i) => {
    const ws = addDays(weekStart(today()), (i - 7) * 7); let a = 0, b = 0
    for (let k = 0; k < 7; k++) { const d = addDays(ws, k); if (d > today()) break; for (const h of habits) if (h.schedule !== 'weekly' && isDue(h, d)) { b++; if (byHabit.get(h.id!)?.has(d)) a++ } }
    return { w: ws.slice(5), pct: b ? Math.round((a / b) * 100) : 0 }
  })
  const month = today().slice(0, 7)
  let ma = 0, mb = 0
  for (let d = month + '-01'; d <= today() && d.startsWith(month); d = addDays(d, 1)) for (const h of habits) if (h.schedule !== 'weekly' && isDue(h, d)) { mb++; if (byHabit.get(h.id!)?.has(d)) ma++ }
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3"><Stat label="This month" value={`${pct(ma, mb)}%`} sub="of daily habits done" /><Stat label="Habits" value={String(habits.length)} /></div>
      <Card><h3 className="font-bold mb-2">Weekly completion</h3><div style={{ height: 150 }}><ResponsiveContainer><BarChart data={weeks}><XAxis dataKey="w" tick={{ fill: 'rgb(var(--mute))', fontSize: 11 }} axisLine={false} tickLine={false} /><YAxis hide domain={[0, 100]} /><Tooltip formatter={(v: number) => `${v}%`} contentStyle={{ background: 'rgb(var(--panel2))', border: '1px solid rgb(var(--line))', borderRadius: 12 }} cursor={{ fill: 'rgb(var(--panel2))' }} /><RBar dataKey="pct" name="Done" fill="#2dd4a8" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></Card>
      {habits.map((h) => { const st = habitStats(h, byHabit.get(h.id!) ?? new Set()); return (
        <Card key={h.id}>
          <p className="font-semibold mb-3">{h.emoji} {h.name}</p>
          <div className="grid grid-cols-4 gap-2 text-center">
            <Mini l={h.schedule === 'weekly' ? 'Week streak' : 'Streak'} v={st.cur} /><Mini l="Best" v={st.best} /><Mini l={h.schedule === 'weekly' ? 'This week' : '7 days'} v={`${st.d7}%`} /><Mini l={h.schedule === 'weekly' ? '4 weeks' : '30 days'} v={`${st.d30}%`} />
          </div>
          {h.schedule !== 'weekly' && <p className="text-xs text-mute mt-3">{st.missed30 > 0 ? `${st.missed30} missed in the last 30 days. Today is a good day to restart.` : 'No missed days in the last 30 days.'}</p>}
        </Card>) })}
    </div>
  )
}
const Mini = ({ l, v }: { l: string; v: string | number }) => <div className="rounded-xl bg-panel2 py-2"><p className="text-lg font-bold num">{v}</p><p className="text-[10px] text-mute">{l}</p></div>

function Manage({ habits, onEdit }: { habits: Habit[]; onEdit: (h: Habit) => void }) {
  const run = useRun(), [del, setDel] = useState<Habit | null>(null)
  const have = new Set(habits.map((h) => h.name))
  return (
    <div className="space-y-4">
      {habits.length === 0 ? <Empty title="No habits yet" /> : (
        <ul className="space-y-2">{habits.map((h) => <li key={h.id} className="rounded-2xl border border-line bg-panel p-3 flex items-center gap-2"><span className="text-xl">{h.emoji}</span><span className="flex-1 font-semibold truncate">{h.name}</span><IconBtn label="Edit" onClick={() => onEdit(h)}><Pencil size={18} /></IconBtn><IconBtn label="Delete" tone="bad" onClick={() => setDel(h)}><Trash2 size={18} /></IconBtn></li>)}</ul>
      )}
      <Card><h3 className="font-bold mb-2">Suggested habits</h3><div className="flex flex-wrap gap-2">{SUGGESTED.filter(([, n]) => !have.has(n)).map(([e, n]) => <button key={n} onClick={() => run(() => db.habits.add({ ...blank(), emoji: e, name: n }), 'Habit added')} className="rounded-full border border-line px-3 py-2 text-sm">+ {e} {n}</button>)}{SUGGESTED.every(([, n]) => have.has(n)) && <p className="text-sm text-mute">You added them all.</p>}</div></Card>
      {del && <Confirm text={`Delete "${del.name}" and its history?`} onNo={() => setDel(null)} onYes={async () => { await run(async () => { await db.habitLogs.where('habitId').equals(del.id!).delete(); await db.habits.delete(del.id!) }, 'Deleted'); setDel(null) }} />}
    </div>
  )
}

function HabitForm({ h, onClose }: { h: Habit; onClose: () => void }) {
  const run = useRun(), [f, setF] = useState(h)
  return (
    <Modal title={f.id ? 'Edit habit' : 'New habit'} onClose={onClose}>
      <div className="grid grid-cols-[84px_1fr] gap-3"><Field label="Emoji"><input className="inp text-center" maxLength={4} value={f.emoji} onChange={(e) => setF({ ...f, emoji: e.target.value })} /></Field><Field label="Name"><input className="inp" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoFocus={!f.id} /></Field></div>
      <Field label="Schedule"><select className="inp" value={f.schedule} onChange={(e) => setF({ ...f, schedule: e.target.value as Habit['schedule'] })}><option value="daily">Every day</option><option value="days">Selected days</option><option value="weekly">Some times per week</option></select></Field>
      {f.schedule === 'days' && <div className="flex flex-wrap gap-2 mb-3">{DAYS.map((d, i) => <button key={d} type="button" onClick={() => setF({ ...f, days: f.days.includes(i) ? f.days.filter((x) => x !== i) : [...f.days, i] })} className={`min-h-[40px] px-3 rounded-full border text-sm font-semibold ${f.days.includes(i) ? 'bg-accent text-on border-accent' : 'border-line text-mute'}`}>{d}</button>)}</div>}
      {f.schedule === 'weekly' && <Field label="Times per week"><input className="inp num" type="number" min={1} max={7} value={f.weeklyTarget} onChange={(e) => setF({ ...f, weeklyTarget: Math.max(1, Math.min(7, Number(e.target.value) || 1)) })} /></Field>}
      <Btn full onClick={async () => { if (!f.name.trim()) return alert('Name the habit.'); if (f.schedule === 'days' && f.days.length === 0) return alert('Pick at least one day.'); const rec = { ...f, name: f.name.trim() }; if (await run(() => (f.id ? db.habits.put(rec) : db.habits.add(rec)), 'Saved')) onClose() }}>Save habit</Btn>
    </Modal>
  )
}

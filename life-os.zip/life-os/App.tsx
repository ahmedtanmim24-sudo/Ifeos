import { Component, useEffect, type ReactNode } from 'react'
import { NavLink, Route, Routes, Link } from 'react-router-dom'
import { Home, Wallet, GraduationCap, Dumbbell, Flame, Sprout, Settings as Cog } from 'lucide-react'
import { ToastProvider, useSettings, cx } from './ui'
import Dashboard from './Dashboard'
import Taka from './Taka'
import Med from './Med'
import Fit from './Fit'
import Habit from './Habit'
import Life from './Life'
import SettingsPage from './Settings'

const NAV = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/taka', label: 'Taka', icon: Wallet },
  { to: '/med', label: 'Med', icon: GraduationCap },
  { to: '/fit', label: 'Fit', icon: Dumbbell },
  { to: '/habit', label: 'Habit', icon: Flame },
  { to: '/life', label: 'Life', icon: Sprout }
]

class Boundary extends Component<{ children: ReactNode }, { err: Error | null }> {
  state = { err: null as Error | null }
  static getDerivedStateFromError(err: Error) { return { err } }
  render() {
    if (!this.state.err) return this.props.children
    return (
      <div className="p-6 text-center">
        <h1 className="text-xl font-bold mb-2">Something went wrong on this screen</h1>
        <p className="text-mute text-sm mb-4">{this.state.err.message}</p>
        <a href="#/" onClick={() => location.reload()} className="text-accent font-semibold">Reload LIFE OS</a>
        <p className="text-xs text-mute mt-4">Your data is stored on this device and was not deleted.</p>
      </div>
    )
  }
}

function Shell() {
  const s = useSettings()
  useEffect(() => {
    document.documentElement.dataset.theme = s.theme
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', s.theme === 'light' ? '#f3f6f4' : '#121413')
  }, [s.theme])
  useEffect(() => { navigator.storage?.persist?.().catch(() => {}) }, [])

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 bg-bg/90 backdrop-blur border-b border-line">
        <div className="mx-auto max-w-xl px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-extrabold tracking-wide text-lg">LIFE<span className="text-accent"> OS</span></Link>
          <Link to="/settings" aria-label="Settings" className="h-10 w-10 grid place-items-center rounded-xl text-mute"><Cog size={22} /></Link>
        </div>
      </header>
      <main className="mx-auto max-w-xl px-4 pt-4 pb-32">
        <Boundary>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/taka" element={<Taka />} />
            <Route path="/med" element={<Med />} />
            <Route path="/fit" element={<Fit />} />
            <Route path="/habit" element={<Habit />} />
            <Route path="/life" element={<Life />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="*" element={<Dashboard />} />
          </Routes>
        </Boundary>
      </main>
      <nav aria-label="Main" className="fixed bottom-0 inset-x-0 z-40 border-t border-line bg-panel/95 backdrop-blur" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        <div className="mx-auto max-w-xl grid grid-cols-6">
          {NAV.map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end}
              className={({ isActive }) => cx('flex flex-col items-center justify-center gap-0.5 h-16 text-[11px] font-semibold', isActive ? 'text-accent' : 'text-mute')}>
              <Icon size={22} />{label}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  )
}

export default function App() {
  return <ToastProvider><Shell /></ToastProvider>
}

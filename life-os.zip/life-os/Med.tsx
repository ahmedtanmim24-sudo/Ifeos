import { useEffect, useMemo, useRef, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Pencil, Trash2, Play, Pause, RotateCcw } from 'lucide-react'
import { Bar, Btn, Card, Check, Confirm, Empty, Fab, Field, IconBtn, Loading, Modal, PageHead, Stat, Tabs, useRun, useSettings, useTabParam } from './ui'
import { db, type Exam, type Session, type Subject, type Topic } from './db'
import { REVISION_GAPS, addDays, dateLabel, daysBetween, hm, num, pct, today, uid } from './lib'

const STATUS: Record<Topic['status'], string> = { todo: 'Not started', doing: 'In progress', done: 'Completed' }
const NEXT: Record<Topic['status'], Topic['status']> = { todo: 'doing', doing: 'done', done: 'todo' }
const PRI_COLOR = { high: 'text-bad', medium: 'text-warn', low: 'text-mute' }

export default function Med() {
  const { tab, setTab } = useTabParam('today')
  return (
    <>
      <PageHead title="MedTrack" sub="Your syllabus, your plan" />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'today', label: 'Today' }, { id: 'topics', label: 'Topics' }, { id: 'timer', label: 'Timer' }, { id: 'exams', label: 'Exams' }]} />
      {tab === 'today' && <TodayTab />}
      {tab === 'topics' && <TopicsTab />}
      {tab === 'timer' && <TimerTab />}
      {tab === 'exams' && <ExamsTab />}
    </>
  )
}

/* ---------------- Today ---------------- */
function TodayTab() {
  const s = useSettings(), run = useRun()
  const topics = useLiveQuery(() => db.topics.toArray(), [])
  const subjects = useLiveQuery(() => db.subjects.toArray(), [])
  const sessions = useLiveQuery(() => db.sessions.toArray(), [])
  const plan = useLiveQuery(() => db.plans.where('date').equals(today()).toArray(), [])
  const exams = useLiveQuery(() => db.exams.toArray(), [])
  const [text, setText] = useState('')
  if (!topics || !subjects || !sessions || !plan || !exams) return <Loading />
  const t0 = today()
  const todayMin = sessions.filter((x) => x.date === t0).reduce((a, x) => a + x.minutes, 0)
  const totalMin = sessions.reduce((a, x) => a + x.minutes, 0)
  const due = topics.flatMap((t) => t.revisions.map((r, i) => ({ t, r, i }))).filter((x) => !x.r.done && x.r.date <= t0).sort((a, b) => a.r.date.localeCompare(b.r.date))
  const next = exams.filter((e) => e.date >= t0).sort((a, b) => a.date.localeCompare(b.date))[0]
  const done = topics.filter((t) => t.status === 'done').length
  const markRev = (t: Topic, i: number) => run(() => db.topics.put({ ...t, revisions: t.revisions.map((r, j) => (j === i ? { ...r, done: true } : r)) }), 'Revision done')

  return (
    <div className="space-y-4">
      {next && <Card className="flex items-center gap-4"><div className="text-center"><p className="text-3xl font-extrabold num text-accent">{daysBetween(t0, next.date)}</p><p className="text-xs text-mute">days</p></div><div><p className="font-semibold">{next.name}</p><p className="text-sm text-mute">{dateLabel(next.date)}</p></div></Card>}
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Studied today" value={hm(todayMin)} sub={`target ${hm(s.studyTargetMin)}`} />
        <Stat label="Total study time" value={hm(totalMin)} />
        <Stat label="Topics completed" value={`${done} / ${topics.length}`} />
        <Stat label="Revisions due" value={String(due.length)} tone={due.length ? 'warn' : undefined} />
      </div>
      <Card><Bar value={todayMin} max={s.studyTargetMin} /><p className="text-xs text-mute mt-2">{pct(todayMin, s.studyTargetMin)}% of today's study target. Change the target in Settings.</p></Card>

      <Card>
        <h3 className="font-bold mb-3">Revisions due</h3>
        {due.length === 0 ? <p className="text-sm text-mute">Nothing due. When you schedule revisions for a topic, they appear here on their date.</p> : (
          <ul className="space-y-3">{due.map(({ t, r, i }) => (
            <li key={t.id + '-' + i} className="flex items-center gap-3">
              <Check on={false} label={`Mark revision of ${t.title} done`} onClick={() => markRev(t, i)} />
              <div className="min-w-0"><p className="font-medium truncate">{t.title}</p><p className="text-xs text-mute">{subjects.find((s) => s.id === t.subjectId)?.name} · {r.date < t0 ? `overdue since ${dateLabel(r.date)}` : 'today'}</p></div>
            </li>))}</ul>
        )}
      </Card>

      <Card>
        <h3 className="font-bold mb-3">Today's study plan</h3>
        <form className="flex gap-2 mb-3" onSubmit={async (e) => { e.preventDefault(); const v = text.trim(); if (!v) return; await run(() => db.plans.add({ date: t0, text: v, done: false })); setText('') }}>
          <input className="inp" placeholder="What will you study today?" value={text} onChange={(e) => setText(e.target.value)} /><Btn type="submit">Add</Btn>
        </form>
        {plan.length === 0 ? <p className="text-sm text-mute">No targets yet for today.</p> : (
          <ul className="space-y-2">{plan.map((p) => (
            <li key={p.id} className="flex items-center gap-3">
              <Check on={p.done} label={p.text} onClick={() => run(() => db.plans.put({ ...p, done: !p.done }))} />
              <span className={`flex-1 ${p.done ? 'line-through text-mute' : ''}`}>{p.text}</span>
              <IconBtn label="Delete" tone="bad" onClick={() => run(() => db.plans.delete(p.id!))}><Trash2 size={18} /></IconBtn>
            </li>))}</ul>
        )}
      </Card>

      <Card>
        <h3 className="font-bold mb-3">Progress by subject</h3>
        {subjects.length === 0 ? <p className="text-sm text-mute">Add a subject in the Topics tab.</p> : subjects.map((sub) => {
          const ts = topics.filter((t) => t.subjectId === sub.id), d = ts.filter((t) => t.status === 'done').length
          return <div key={sub.id} className="mb-3 last:mb-0"><div className="flex justify-between text-sm mb-1"><span>{sub.name}</span><span className="num text-mute">{d}/{ts.length}</span></div><Bar value={d} max={ts.length} /></div>
        })}
      </Card>
    </div>
  )
}

/* ---------------- Topics ---------------- */
function TopicsTab() {
  const run = useRun()
  const subjects = useLiveQuery(() => db.subjects.toArray(), [])
  const topics = useLiveQuery(() => db.topics.toArray(), [])
  const [sub, setSub] = useState<number | 0>(0), [status, setStatus] = useState(''), [form, setForm] = useState<Topic | null>(null)
  const [subForm, setSubForm] = useState<Subject | null>(null), [del, setDel] = useState<Topic | null>(null), [delSub, setDelSub] = useState<Subject | null>(null)
  if (!subjects || !topics) return <Loading />
  const rows = topics.filter((t) => (!sub || t.subjectId === sub) && (!status || t.status === status))
    .sort((a, b) => (a.paper + a.chapter).localeCompare(b.paper + b.chapter) || a.title.localeCompare(b.title))
  const newTopic = (): Topic => ({ subjectId: sub || subjects[0]?.id || 0, paper: '', chapter: '', title: '', subtopic: '', status: 'todo', priority: 'medium', notes: '', revisions: [], createdAt: today() })

  return (
    <div>
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 mb-2">
        <Chip on={!sub} onClick={() => setSub(0)}>All</Chip>
        {subjects.map((s) => <Chip key={s.id} on={sub === s.id} onClick={() => setSub(s.id!)}>{s.name}</Chip>)}
        <button onClick={() => setSubForm({ name: '' })} className="shrink-0 min-h-[40px] px-4 rounded-full border border-dashed border-accent text-accent text-sm font-semibold">+ Subject</button>
      </div>
      {sub !== 0 && (
        <div className="flex gap-2 mb-3">
          <Btn small variant="ghost" onClick={() => setSubForm(subjects.find((s) => s.id === sub)!)}>Rename subject</Btn>
          <Btn small variant="danger" onClick={() => setDelSub(subjects.find((s) => s.id === sub)!)}>Delete subject</Btn>
        </div>
      )}
      <select className="inp mb-4" aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="">All statuses</option>{Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
      </select>

      {subjects.length === 0 ? <Empty title="No subjects yet" text="Add your first subject to start building your syllabus." /> : rows.length === 0 ? (
        <Empty title="No topics here yet" text="Add the topics from your own syllabus. LIFE OS does not include any syllabus." action={<Btn onClick={() => setForm(newTopic())}>Add a topic</Btn>} />
      ) : (
        <ul className="space-y-2">
          {rows.map((t) => {
            const nextRev = t.revisions.filter((r) => !r.done).sort((a, b) => a.date.localeCompare(b.date))[0]
            return (
              <li key={t.id} className="rounded-2xl border border-line bg-panel p-3">
                <div className="flex items-start gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">{t.title}{t.subtopic ? <span className="text-mute font-normal"> · {t.subtopic}</span> : null}</p>
                    <p className="text-xs text-mute">{[subjects.find((s) => s.id === t.subjectId)?.name, t.paper, t.chapter].filter(Boolean).join(' · ')}</p>
                    <p className="text-xs mt-1"><span className={PRI_COLOR[t.priority]}>{t.priority} priority</span>{nextRev ? <span className="text-mute"> · next revision {dateLabel(nextRev.date)}</span> : null}</p>
                  </div>
                  <IconBtn label="Edit" onClick={() => setForm(t)}><Pencil size={18} /></IconBtn>
                  <IconBtn label="Delete" tone="bad" onClick={() => setDel(t)}><Trash2 size={18} /></IconBtn>
                </div>
                <button onClick={() => run(() => db.topics.put({ ...t, status: NEXT[t.status] }))}
                  className={`mt-2 rounded-full px-3 py-1.5 text-xs font-semibold border ${t.status === 'done' ? 'bg-accent text-on border-accent' : t.status === 'doing' ? 'bg-accent/15 text-accent border-accent/40' : 'border-line text-mute'}`}>
                  {STATUS[t.status]} (tap to change)
                </button>
              </li>
            )
          })}
        </ul>
      )}
      {subjects.length > 0 && <Fab label="Topic" onClick={() => setForm(newTopic())} />}
      {form && <TopicForm t={form} subjects={subjects} onClose={() => setForm(null)} />}
      {subForm && <SubjectForm s={subForm} onClose={() => setSubForm(null)} />}
      {del && <Confirm text={`Delete the topic "${del.title}" and its notes?`} onNo={() => setDel(null)} onYes={async () => { await run(() => db.topics.delete(del.id!), 'Deleted'); setDel(null) }} />}
      {delSub && <Confirm text={`Delete "${delSub.name}" and all of its topics? Study sessions stay in your total time.`} yes="Delete all" onNo={() => setDelSub(null)}
        onYes={async () => { await run(async () => { await db.topics.where('subjectId').equals(delSub.id!).delete(); await db.subjects.delete(delSub.id!) }, 'Deleted'); setSub(0); setDelSub(null) }} />}
    </div>
  )
}
const Chip = ({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) => (
  <button onClick={onClick} className={`shrink-0 min-h-[40px] px-4 rounded-full text-sm font-semibold border ${on ? 'bg-accent text-on border-accent' : 'border-line text-mute'}`}>{children}</button>
)

function SubjectForm({ s, onClose }: { s: Subject; onClose: () => void }) {
  const run = useRun(), [n, setN] = useState(s.name)
  return (
    <Modal title={s.id ? 'Rename subject' : 'New subject'} onClose={onClose}>
      <Field label="Subject name"><input className="inp" value={n} onChange={(e) => setN(e.target.value)} autoFocus /></Field>
      <Btn full onClick={async () => { if (!n.trim()) return; const ok = await run(() => (s.id ? db.subjects.put({ ...s, name: n.trim() }) : db.subjects.add({ name: n.trim() })), 'Saved'); if (ok) onClose() }}>Save</Btn>
    </Modal>
  )
}

function TopicForm({ t, subjects, onClose }: { t: Topic; subjects: Subject[]; onClose: () => void }) {
  const run = useRun(), [f, setF] = useState(t), [rd, setRd] = useState(today())
  const set = <K extends keyof Topic>(k: K, v: Topic[K]) => setF((p) => ({ ...p, [k]: v }))
  const spaced = () => set('revisions', [...f.revisions, ...REVISION_GAPS.map((g) => ({ date: addDays(rd, g), done: false }))].sort((a, b) => a.date.localeCompare(b.date)))
  const save = async () => {
    if (!f.title.trim()) return alert('Give the topic a name.')
    const rec = { ...f, title: f.title.trim() }
    const ok = await run(() => (f.id ? db.topics.put(rec) : db.topics.add(rec)), 'Saved'); if (ok) onClose()
  }
  return (
    <Modal title={f.id ? 'Edit topic' : 'New topic'} onClose={onClose}>
      <Field label="Subject"><select className="inp" value={f.subjectId} onChange={(e) => set('subjectId', Number(e.target.value))}>{subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Paper"><input className="inp" placeholder="e.g. Paper 1" value={f.paper} onChange={(e) => set('paper', e.target.value)} /></Field>
        <Field label="Chapter"><input className="inp" value={f.chapter} onChange={(e) => set('chapter', e.target.value)} /></Field>
      </div>
      <Field label="Topic"><input className="inp" value={f.title} onChange={(e) => set('title', e.target.value)} autoFocus={!f.id} /></Field>
      <Field label="Subtopic (optional)"><input className="inp" value={f.subtopic} onChange={(e) => set('subtopic', e.target.value)} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Status"><select className="inp" value={f.status} onChange={(e) => set('status', e.target.value as Topic['status'])}>{Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
        <Field label="Priority"><select className="inp" value={f.priority} onChange={(e) => set('priority', e.target.value as Topic['priority'])}><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select></Field>
      </div>
      <Field label="Notes"><textarea className="inp" value={f.notes} onChange={(e) => set('notes', e.target.value)} /></Field>
      <div className="rounded-2xl bg-panel2 p-3 mb-4">
        <p className="font-semibold mb-2">Revisions</p>
        {f.revisions.length === 0 && <p className="text-sm text-mute mb-2">None scheduled.</p>}
        <ul className="space-y-1 mb-3">{f.revisions.map((r, i) => (
          <li key={i} className="flex items-center gap-2 text-sm">
            <Check on={r.done} label="Revision done" onClick={() => set('revisions', f.revisions.map((x, j) => (j === i ? { ...x, done: !x.done } : x)))} />
            <span className="flex-1 num">{dateLabel(r.date)}</span>
            <IconBtn label="Remove revision" tone="bad" onClick={() => set('revisions', f.revisions.filter((_, j) => j !== i))}><Trash2 size={16} /></IconBtn>
          </li>))}</ul>
        <Field label="Start from"><input type="date" className="inp" value={rd} onChange={(e) => setRd(e.target.value || today())} /></Field>
        <div className="flex gap-2">
          <Btn small variant="soft" onClick={spaced}>Add spaced revisions (+{REVISION_GAPS.join(', ')} days)</Btn>
          <Btn small variant="ghost" onClick={() => set('revisions', [...f.revisions, { date: rd, done: false }].sort((a, b) => a.date.localeCompare(b.date)))}>Add this date</Btn>
        </div>
      </div>
      <Btn full onClick={save}>Save topic</Btn>
    </Modal>
  )
}

/* ---------------- Timer + sessions ---------------- */
function TimerTab() {
  const run = useRun()
  const subjects = useLiveQuery(() => db.subjects.toArray(), [])
  const sessions = useLiveQuery(() => db.sessions.orderBy('date').reverse().toArray(), [])
  const [focus, setFocus] = useState(25), [brk, setBrk] = useState(5), [mode, setMode] = useState<'focus' | 'break'>('focus')
  const [left, setLeft] = useState(25 * 60), [running, setRunning] = useState(false), [subId, setSubId] = useState(0)
  const endAt = useRef(0)
  const [manual, setManual] = useState<Session | null>(null), [del, setDel] = useState<Session | null>(null)

  useEffect(() => {
    if (!running) return
    const id = setInterval(async () => {
      const r = Math.ceil((endAt.current - Date.now()) / 1000)
      if (r > 0) { setLeft(r); return }
      setRunning(false)
      navigator.vibrate?.([200, 100, 200])
      if (mode === 'focus') {
        await run(() => db.sessions.add({ date: today(), minutes: focus, subjectId: subId || undefined, note: 'Pomodoro' }), `Focus session saved: ${focus} min`)
        setMode('break'); setLeft(brk * 60)
      } else { setMode('focus'); setLeft(focus * 60) }
    }, 500)
    return () => clearInterval(id)
  }, [running, mode, focus, brk, subId])

  const start = () => { endAt.current = Date.now() + left * 1000; setRunning(true) }
  const reset = () => { setRunning(false); setMode('focus'); setLeft(focus * 60) }
  const mm = String(Math.floor(left / 60)).padStart(2, '0'), ss = String(left % 60).padStart(2, '0')
  if (!subjects || !sessions) return <Loading />

  return (
    <div className="space-y-4">
      <Card className="text-center">
        <p className="text-sm text-mute mb-1">{mode === 'focus' ? 'Focus' : 'Break'}</p>
        <p className="text-6xl font-extrabold num tracking-tight my-2" aria-live="off">{mm}:{ss}</p>
        <div className="flex justify-center gap-3 mt-3">
          {running ? <Btn onClick={() => setRunning(false)}><Pause size={20} /> Pause</Btn> : <Btn onClick={start}><Play size={20} /> {left < (mode === 'focus' ? focus : brk) * 60 ? 'Resume' : 'Start'}</Btn>}
          <Btn variant="ghost" onClick={reset}><RotateCcw size={18} /> Reset</Btn>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-4 text-left">
          <Field label="Focus (min)"><input className="inp num" inputMode="numeric" value={focus} disabled={running} onChange={(e) => { const v = Math.max(1, Math.min(180, num(e.target.value) || 1)); setFocus(v); if (mode === 'focus') setLeft(v * 60) }} /></Field>
          <Field label="Break (min)"><input className="inp num" inputMode="numeric" value={brk} disabled={running} onChange={(e) => { const v = Math.max(1, Math.min(60, num(e.target.value) || 1)); setBrk(v); if (mode === 'break') setLeft(v * 60) }} /></Field>
          <Field label="Subject"><select className="inp" value={subId} onChange={(e) => setSubId(Number(e.target.value))}><option value={0}>None</option>{subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
        </div>
        <p className="text-xs text-mute">Each finished focus round is saved as a study session. Keep this screen open while the timer runs; it may pause if your phone locks the app.</p>
      </Card>
      <div className="flex items-center justify-between"><h3 className="font-bold">Study sessions</h3><Btn small onClick={() => setManual({ date: today(), minutes: 0, note: '' })}>Log a session</Btn></div>
      {sessions.length === 0 ? <Empty title="No sessions yet" text="Finish a focus round or log time you already studied." /> : (
        <ul className="space-y-2">{sessions.slice(0, 40).map((x) => (
          <li key={x.id} className="rounded-2xl border border-line bg-panel p-3 flex items-center gap-2">
            <div className="flex-1 min-w-0"><p className="font-semibold num">{hm(x.minutes)}</p><p className="text-xs text-mute truncate">{dateLabel(x.date)} · {subjects.find((s) => s.id === x.subjectId)?.name || 'No subject'}{x.note ? ` · ${x.note}` : ''}</p></div>
            <IconBtn label="Delete" tone="bad" onClick={() => setDel(x)}><Trash2 size={18} /></IconBtn>
          </li>))}</ul>
      )}
      {manual && <SessionForm s={manual} subjects={subjects} onClose={() => setManual(null)} />}
      {del && <Confirm text="Delete this study session?" onNo={() => setDel(null)} onYes={async () => { await run(() => db.sessions.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}
function SessionForm({ s, subjects, onClose }: { s: Session; subjects: Subject[]; onClose: () => void }) {
  const run = useRun(), [f, setF] = useState(s), [m, setM] = useState('')
  return (
    <Modal title="Log study time" onClose={onClose}>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Minutes"><input className="inp num" inputMode="numeric" value={m} onChange={(e) => setM(e.target.value)} autoFocus /></Field>
        <Field label="Date"><input type="date" className="inp" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value || today() })} /></Field>
      </div>
      <Field label="Subject"><select className="inp" value={f.subjectId ?? 0} onChange={(e) => setF({ ...f, subjectId: Number(e.target.value) || undefined })}><option value={0}>None</option>{subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
      <Field label="Note (optional)"><input className="inp" value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></Field>
      <Btn full onClick={async () => { const mins = Math.round(num(m)); if (mins <= 0) return alert('Enter the minutes you studied.'); const ok = await run(() => db.sessions.add({ ...f, minutes: mins }), 'Saved'); if (ok) onClose() }}>Save</Btn>
    </Modal>
  )
}

/* ---------------- Exams ---------------- */
function ExamsTab() {
  const run = useRun()
  const exams = useLiveQuery(() => db.exams.orderBy('date').toArray(), [])
  const subjects = useLiveQuery(() => db.subjects.toArray(), [])
  const [form, setForm] = useState<Exam | null>(null), [del, setDel] = useState<Exam | null>(null)
  if (!exams || !subjects) return <Loading />
  const t0 = today()
  return (
    <div>
      {exams.length === 0 ? <Empty title="No exams yet" text="Add an exam date to see a countdown on your Today tab and Home." action={<Btn onClick={() => setForm({ name: '', date: t0, notes: '' })}>Add exam</Btn>} /> : (
        <ul className="space-y-2">{exams.map((e) => {
          const d = daysBetween(t0, e.date)
          return (
            <li key={e.id} className="rounded-2xl border border-line bg-panel p-3 flex items-center gap-3">
              <div className="w-16 text-center"><p className={`text-2xl font-extrabold num ${d < 0 ? 'text-mute' : 'text-accent'}`}>{Math.abs(d)}</p><p className="text-[11px] text-mute">{d < 0 ? 'days ago' : d === 0 ? 'today' : 'days left'}</p></div>
              <div className="flex-1 min-w-0"><p className="font-semibold truncate">{e.name}</p><p className="text-xs text-mute">{dateLabel(e.date)}{e.subjectId ? ` · ${subjects.find((s) => s.id === e.subjectId)?.name ?? ''}` : ''}</p></div>
              <IconBtn label="Edit" onClick={() => setForm(e)}><Pencil size={18} /></IconBtn>
              <IconBtn label="Delete" tone="bad" onClick={() => setDel(e)}><Trash2 size={18} /></IconBtn>
            </li>)
        })}</ul>
      )}
      {exams.length > 0 && <Fab label="Exam" onClick={() => setForm({ name: '', date: t0, notes: '' })} />}
      {form && <ExamForm e={form} subjects={subjects} onClose={() => setForm(null)} />}
      {del && <Confirm text={`Delete "${del.name}"?`} onNo={() => setDel(null)} onYes={async () => { await run(() => db.exams.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}
function ExamForm({ e, subjects, onClose }: { e: Exam; subjects: Subject[]; onClose: () => void }) {
  const run = useRun(), [f, setF] = useState(e)
  return (
    <Modal title={f.id ? 'Edit exam' : 'New exam'} onClose={onClose}>
      <Field label="Exam name"><input className="inp" value={f.name} onChange={(x) => setF({ ...f, name: x.target.value })} autoFocus /></Field>
      <Field label="Exam date"><input type="date" className="inp" value={f.date} onChange={(x) => setF({ ...f, date: x.target.value || today() })} /></Field>
      <Field label="Subject (optional)"><select className="inp" value={f.subjectId ?? 0} onChange={(x) => setF({ ...f, subjectId: Number(x.target.value) || undefined })}><option value={0}>Any</option>{subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>
      <Field label="Notes (optional)"><input className="inp" value={f.notes} onChange={(x) => setF({ ...f, notes: x.target.value })} /></Field>
      <Btn full onClick={async () => { if (!f.name.trim()) return alert('Give the exam a name.'); const ok = await run(() => (f.id ? db.exams.put(f) : db.exams.add(f)), 'Saved'); if (ok) onClose() }}>Save</Btn>
    </Modal>
  )
}

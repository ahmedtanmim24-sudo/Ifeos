import { useMemo } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useLiveQuery } from 'dexie-react-hooks'
import { Droplets, Plus } from 'lucide-react'
import { Bar, Card, Check, Ring, Stat, useRun, useSettings } from './ui'
import { db } from './db'
import { daysBetween, hm, longDate, monthOf, money, pct, today } from './lib'
import { isDue, toggleHabit } from './Habit'
import { PRAYERS, togglePrayer } from './Life'

const PN: Record<string, string> = { fajr: 'Fajr', dhuhr: 'Dhuhr', asr: 'Asr', maghrib: 'Maghrib', isha: 'Isha' }

export default function Dashboard() {
  const s = useSettings(), run = useRun(), nav = useNavigate(), t0 = today()
  const data = useLiveQuery(async () => ({
    habits: await db.habits.toArray(), logs: await db.habitLogs.where('date').equals(t0).toArray(),
    prayer: await db.prayers.get(t0), tasks: await db.tasks.toArray(), sessions: await db.sessions.where('date').equals(t0).toArray(),
    topics: await db.topics.toArray(), exams: await db.exams.toArray(), txns: await db.transactions.orderBy('date').reverse().toArray(),
    daily: await db.daily.get(t0), meals: await db.meals.where('date').equals(t0).toArray(), weights: await db.weights.orderBy('date').toArray(),
    sleep: await db.sleep.orderBy('date').reverse().first()
  }), [t0])

  const calc = useMemo(() => {
    if (!data) return null
    const dueHabits = data.habits.filter((h) => isDue(h, t0)), doneHabits = dueHabits.filter((h) => data.logs.some((l) => l.habitId === h.id))
    const prayers = PRAYERS.filter((k) => data.prayer?.done[k]).length
    const openToday = data.tasks.filter((t) => !t.done && t.dueDate && t.dueDate <= t0), doneToday = data.tasks.filter((t) => t.done && t.doneAt === t0)
    const studyMin = data.sessions.reduce((a, x) => a + x.minutes, 0)
    const parts: [string, number][] = [['Prayers', prayers / 5], ['Study', Math.min(1, studyMin / Math.max(1, s.studyTargetMin))]]
    if (dueHabits.length) parts.push(['Habits', doneHabits.length / dueHabits.length])
    if (openToday.length + doneToday.length) parts.push(['Tasks', doneToday.length / (openToday.length + doneToday.length)])
    const score = Math.round((parts.reduce((a, [, v]) => a + v, 0) / parts.length) * 100)
    return { dueHabits, doneHabits, prayers, openToday, doneToday, studyMin, parts, score }
  }, [data, s.studyTargetMin, t0])

  if (!data || !calc) return <div className="p-6 text-center text-mute animate-pulse">Loading…</div>
  const hr = new Date().getHours(), greet = hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening'
  const m = monthOf(t0)
  const inc = data.txns.filter((t) => t.type === 'income' && monthOf(t.date) === m).reduce((a, t) => a + t.amount, 0)
  const exp = data.txns.filter((t) => t.type === 'expense' && monthOf(t.date) === m).reduce((a, t) => a + t.amount, 0)
  const dueRev = data.topics.reduce((a, t) => a + t.revisions.filter((r) => !r.done && r.date <= t0).length, 0)
  const exam = data.exams.filter((e) => e.date >= t0).sort((a, b) => a.date.localeCompare(b.date))[0]
  const water = data.daily?.waterMl ?? 0, kcal = data.meals.reduce((a, x) => a + x.kcal, 0), w = data.weights[data.weights.length - 1]
  const quick: [string, string][] = [['Expense', '/taka?tab=txns&add=expense'], ['Income', '/taka?tab=txns&add=income'], ['Task', '/life?tab=tasks&add=1'], ['Meal', '/fit?tab=meals&add=1'], ['Weight', '/fit?tab=weight&add=1'], ['Study', '/med?tab=timer']]

  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm text-mute">{longDate()}</p>
        <h1 className="text-2xl font-extrabold tracking-tight">{greet}{s.name ? `, ${s.name}` : ''}</h1>
      </div>

      <Card className="flex items-center gap-5">
        <Ring value={calc.score} size={132} stroke={13}><div><p className="text-3xl font-extrabold num">{calc.score}%</p><p className="text-[11px] text-mute">of today</p></div></Ring>
        <ul className="flex-1 space-y-2 min-w-0">{calc.parts.map(([n, v]) => <li key={n}><div className="flex justify-between text-xs mb-1"><span>{n}</span><span className="num text-mute">{Math.round(v * 100)}%</span></div><Bar value={v} max={1} h={6} /></li>)}</ul>
      </Card>

      <div className="flex gap-2 overflow-x-auto -mx-4 px-4 pb-1">
        {quick.map(([l, to]) => <button key={l} onClick={() => nav(to)} className="shrink-0 min-h-[44px] px-4 rounded-full border border-line bg-panel text-sm font-semibold flex items-center gap-1"><Plus size={16} className="text-accent" />{l}</button>)}
        <button onClick={() => run(() => db.daily.put({ date: t0, waterMl: water + 250, steps: data.daily?.steps ?? 0, activity: data.daily?.activity ?? '' }), '+250 ml water')} className="shrink-0 min-h-[44px] px-4 rounded-full border border-line bg-panel text-sm font-semibold flex items-center gap-1"><Droplets size={16} className="text-accent" />250 ml</button>
      </div>

      <Section title="Study" to="/med">
        <div className="grid grid-cols-3 gap-2"><Stat label="Today" value={hm(calc.studyMin)} sub={`of ${hm(s.studyTargetMin)}`} /><Stat label="Revisions due" value={String(dueRev)} tone={dueRev ? 'warn' : undefined} /><Stat label="Exam" value={exam ? `${daysBetween(t0, exam.date)}d` : '-'} sub={exam?.name} /></div>
      </Section>

      <Section title="Habits due today" to="/habit">
        {calc.dueHabits.length === 0 ? <p className="text-sm text-mute">{data.habits.length ? 'Nothing scheduled today.' : 'No habits yet. Add one in HabitTrack.'}</p> : <ul className="space-y-2.5">{calc.dueHabits.map((h) => { const on = data.logs.some((l) => l.habitId === h.id); return <li key={h.id} className="flex items-center gap-3"><Check on={on} label={`Mark ${h.name} done`} onClick={() => run(() => toggleHabit(h, t0, on ? new Set([t0]) : new Set()))} /><span className={on ? 'text-mute line-through' : ''}>{h.emoji} {h.name}</span></li> })}</ul>}
      </Section>

      <Section title="Prayers" to="/life?tab=prayers">
        <div className="grid grid-cols-5 gap-1.5">{PRAYERS.map((k) => { const on = !!data.prayer?.done[k]; return <button key={k} onClick={() => run(() => togglePrayer(t0, k, data.prayer))} aria-pressed={on} className={`min-h-[48px] rounded-2xl text-xs font-semibold border ${on ? 'bg-accent text-on border-accent' : 'border-line text-mute'}`}>{PN[k]}</button> })}</div>
      </Section>

      <Section title="Today's tasks" to="/life?tab=tasks">
        {calc.openToday.length + calc.doneToday.length === 0 ? <p className="text-sm text-mute">No tasks due today.</p> : <ul className="space-y-2.5">{[...calc.openToday.slice(0, 5), ...calc.doneToday.slice(0, 3)].map((t) => <li key={t.id} className="flex items-center gap-3"><Check on={t.done} label={t.title} onClick={() => run(() => db.tasks.put({ ...t, done: !t.done, doneAt: !t.done ? t0 : undefined }))} /><span className={t.done ? 'text-mute line-through' : ''}>{t.title}</span></li>)}</ul>}
      </Section>

      <Section title={`Money this month`} to="/taka">
        <div className="grid grid-cols-3 gap-2"><Stat label="Income" value={money(inc, s.currency)} tone="good" /><Stat label="Expenses" value={money(exp, s.currency)} tone="bad" /><Stat label={s.monthlyBudget ? 'Budget left' : 'Net'} value={money(s.monthlyBudget ? s.monthlyBudget - exp : inc - exp, s.currency)} /></div>
        {data.txns.slice(0, 3).length > 0 && <ul className="mt-3 space-y-1.5">{data.txns.slice(0, 3).map((t) => <li key={t.id} className="flex justify-between text-sm"><span className="truncate">{t.category}{t.note ? ` · ${t.note}` : ''}</span><span className={`num ${t.type === 'income' ? 'text-good' : ''}`}>{t.type === 'income' ? '+' : '-'}{money(t.amount, s.currency)}</span></li>)}</ul>}
      </Section>

      <Section title="Fitness and sleep" to="/fit">
        <div className="grid grid-cols-2 gap-2"><Stat label="Water" value={`${water} ml`} sub={`${pct(water, s.waterTargetMl)}% of target`} /><Stat label="Weight" value={w ? `${w.kg} kg` : 'Not logged'} /><Stat label="Calories (est.)" value={String(kcal)} sub={`target ${s.calorieTarget}`} /><Stat label="Last sleep" value={data.sleep ? hm(data.sleep.minutes) : 'Not logged'} sub={`target ${s.sleepTargetH}h`} /></div>
      </Section>
    </div>
  )
}

function Section({ title, to, children }: { title: string; to: string; children: React.ReactNode }) {
  return (
    <Card>
      <div className="flex items-center justify-between mb-3"><h2 className="font-bold">{title}</h2><Link to={to} className="text-sm text-accent font-semibold min-h-[32px] flex items-center">Open</Link></div>
      {children}
    </Card>
  )
}

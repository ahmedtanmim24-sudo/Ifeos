import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { X } from 'lucide-react'
import { useLiveQuery } from 'dexie-react-hooks'
import { useSearchParams } from 'react-router-dom'
import { db, DEFAULT_SETTINGS, saveSettings, type Settings } from './db'

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(' ')

/* ---------- settings hook ---------- */
export function useSettings(): Settings {
  const r = useLiveQuery(async () => ({ s: await db.settings.get('main') }), [])
  return { ...DEFAULT_SETTINGS, ...(r?.s ?? {}) } as Settings
}
export { saveSettings }

/* ---------- toast + safe runner ---------- */
type ToastFn = (msg: string, kind?: 'ok' | 'err') => void
const ToastCtx = createContext<ToastFn>(() => {})
export const useToast = () => useContext(ToastCtx)

export function ToastProvider({ children }: { children: ReactNode }) {
  const [t, setT] = useState<{ msg: string; kind: 'ok' | 'err' } | null>(null)
  const show = useCallback<ToastFn>((msg, kind = 'ok') => {
    setT({ msg, kind })
    setTimeout(() => setT(null), kind === 'err' ? 5000 : 2200)
  }, [])
  return (
    <ToastCtx.Provider value={show}>
      {children}
      {t && (
        <div role="status" className={cx('fixed left-1/2 -translate-x-1/2 bottom-24 z-[70] max-w-[90vw] rounded-2xl px-4 py-3 text-sm font-medium shadow-lg border',
          t.kind === 'err' ? 'bg-bad/15 border-bad/40 text-bad' : 'bg-panel border-line text-ink')}>
          {t.msg}
        </div>
      )}
    </ToastCtx.Provider>
  )
}

/** Wraps database writes so a failure shows a clear message instead of silently breaking. */
export function useRun() {
  const toast = useToast()
  return useCallback(async (fn: () => Promise<unknown>, ok?: string) => {
    try { await fn(); if (ok) toast(ok); return true }
    catch (e) { toast('Could not save: ' + ((e as Error)?.message || 'unknown error'), 'err'); return false }
  }, [toast])
}

/* ---------- tab + add flag from the URL (used by quick-add buttons) ---------- */
export function useTabParam(def: string) {
  const [sp, setSp] = useSearchParams()
  const tab = sp.get('tab') || def
  const add = sp.get('add')
  const setTab = (t: string) => setSp({ tab: t }, { replace: true })
  const clearAdd = () => { const n = new URLSearchParams(sp); n.delete('add'); setSp(n, { replace: true }) }
  return { tab, setTab, add, clearAdd }
}

/* ---------- layout pieces ---------- */
export function Card({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return <div onClick={onClick} className={cx('rounded-xl2 border border-line bg-panel p-4', className)}>{children}</div>
}

export function Btn({ children, onClick, variant = 'primary', type = 'button', className, disabled, full, small }: {
  children: ReactNode; onClick?: () => void; variant?: 'primary' | 'ghost' | 'danger' | 'soft'; type?: 'button' | 'submit'
  className?: string; disabled?: boolean; full?: boolean; small?: boolean
}) {
  const v = {
    primary: 'bg-accent text-on', ghost: 'border border-line text-ink bg-transparent',
    danger: 'bg-bad/15 text-bad border border-bad/40', soft: 'bg-accent/15 text-accent'
  }[variant]
  return (
    <button type={type} disabled={disabled} onClick={onClick}
      className={cx('inline-flex items-center justify-center gap-2 rounded-2xl font-semibold active:scale-[.98] transition disabled:opacity-50',
        small ? 'min-h-[40px] px-3 text-sm' : 'min-h-[48px] px-5 text-base', full && 'w-full', v, className)}>
      {children}
    </button>
  )
}

export function IconBtn({ children, onClick, label, tone }: { children: ReactNode; onClick: () => void; label: string; tone?: 'bad' }) {
  return (
    <button type="button" aria-label={label} onClick={onClick}
      className={cx('h-10 w-10 shrink-0 grid place-items-center rounded-xl active:scale-95', tone === 'bad' ? 'text-bad' : 'text-mute')}>
      {children}
    </button>
  )
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = prev }
  }, [])
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/60" onClick={onClose}>
      <div role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}
        className="sheet-in w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-t-3xl bg-panel border border-line p-5 pb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold">{title}</h2>
          <IconBtn label="Close" onClick={onClose}><X size={22} /></IconBtn>
        </div>
        {children}
      </div>
    </div>
  )
}

export function Confirm({ text, yes = 'Delete', onYes, onNo }: { text: string; yes?: string; onYes: () => void; onNo: () => void }) {
  return (
    <Modal title="Are you sure?" onClose={onNo}>
      <p className="text-mute mb-5">{text}</p>
      <div className="flex gap-3"><Btn variant="ghost" full onClick={onNo}>Cancel</Btn><Btn variant="danger" full onClick={onYes}>{yes}</Btn></div>
    </Modal>
  )
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block mb-3">
      <span className="block text-sm text-mute mb-1.5">{label}</span>
      {children}
      {hint && <span className="block text-xs text-mute mt-1">{hint}</span>}
    </label>
  )
}

export function Empty({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="rounded-xl2 border border-dashed border-line p-6 text-center">
      <p className="font-semibold">{title}</p>
      {text && <p className="text-sm text-mute mt-1">{text}</p>}
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  )
}

export function Bar({ value, max, color = 'rgb(var(--accent))', h = 8 }: { value: number; max: number; color?: string; h?: number }) {
  const p = max > 0 ? Math.min(100, (value / max) * 100) : 0
  return (
    <div className="w-full rounded-full bg-panel2 overflow-hidden" style={{ height: h }} role="progressbar" aria-valuenow={Math.round(p)} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${p}%`, background: color }} />
    </div>
  )
}

export function Ring({ value, size = 150, stroke = 14, children }: { value: number; size?: number; stroke?: number; children?: ReactNode }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, p = Math.max(0, Math.min(100, value))
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgb(var(--panel2))" strokeWidth={stroke} />
        <circle className="ring-draw" cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgb(var(--accent))" strokeWidth={stroke}
          strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - p / 100)} />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  )
}

export function PageHead({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 mb-4">
      <div><h1 className="text-2xl font-extrabold tracking-tight">{title}</h1>{sub && <p className="text-sm text-mute mt-0.5">{sub}</p>}</div>
      {right}
    </div>
  )
}

export function Tabs({ tabs, value, onChange }: { tabs: { id: string; label: string }[]; value: string; onChange: (id: string) => void }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 mb-4 -mx-4 px-4" role="tablist">
      {tabs.map((t) => (
        <button key={t.id} role="tab" aria-selected={value === t.id} onClick={() => onChange(t.id)}
          className={cx('shrink-0 min-h-[40px] px-4 rounded-full text-sm font-semibold border',
            value === t.id ? 'bg-accent text-on border-accent' : 'border-line text-mute')}>
          {t.label}
        </button>
      ))}
    </div>
  )
}

export function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: 'good' | 'bad' | 'warn' }) {
  return (
    <div className="rounded-2xl bg-panel2 p-3 min-w-0">
      <p className="text-xs text-mute">{label}</p>
      <p className={cx('text-lg font-bold num truncate', tone === 'good' && 'text-good', tone === 'bad' && 'text-bad', tone === 'warn' && 'text-warn')}>{value}</p>
      {sub && <p className="text-xs text-mute">{sub}</p>}
    </div>
  )
}

export function Fab({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <button onClick={onClick} aria-label={label}
      className="fixed right-4 bottom-24 z-40 h-14 px-5 rounded-full bg-accent text-on font-bold shadow-xl active:scale-95 flex items-center gap-2">
      <span className="text-2xl leading-none">+</span><span className="text-sm">{label}</span>
    </button>
  )
}

export function Check({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) {
  return (
    <button type="button" role="checkbox" aria-checked={on} aria-label={label} onClick={onClick}
      className={cx('h-8 w-8 shrink-0 rounded-full border-2 grid place-items-center active:scale-90 transition',
        on ? 'bg-accent border-accent text-on' : 'border-line text-transparent')}>
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5 9-10" /></svg>
    </button>
  )
}

export function MonthNav({ month, onChange, label }: { month: string; onChange: (m: string) => void; label: string }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <Btn small variant="ghost" onClick={() => onChange(shiftMonth(month, -1))}>‹</Btn>
      <span className="font-semibold">{label}</span>
      <Btn small variant="ghost" onClick={() => onChange(shiftMonth(month, 1))}>›</Btn>
    </div>
  )
}
function shiftMonth(m: string, n: number) {
  const d = new Date(m + '-01T00:00:00'); d.setMonth(d.getMonth() + n)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
}

export function Loading() {
  return <div className="p-6 text-center text-mute animate-pulse">Loading…</div>
}

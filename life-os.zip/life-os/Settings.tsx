import { useEffect, useRef, useState } from 'react'
import { Download, Upload, FileSpreadsheet, Trash2, ShieldAlert } from 'lucide-react'
import { Btn, Card, Confirm, Field, Modal, PageHead, saveSettings, useRun, useSettings, useToast } from './ui'
import { buildBackup, download, num, resetAll, restoreBackup, today, transactionsCsv, validateBackup } from './lib'
import type { Settings } from './db'

const CURRENCIES = [['৳', 'Bangladeshi Taka (৳)'], ['$', 'US Dollar ($)'], ['€', 'Euro (€)'], ['£', 'British Pound (£)'], ['₹', 'Indian Rupee (₹)'], ['Rs', 'Rupee (Rs)'], ['AED ', 'UAE Dirham (AED)'], ['SAR ', 'Saudi Riyal (SAR)']]

export default function SettingsPage() {
  const s = useSettings(), run = useRun(), toast = useToast()
  const [name, setName] = useState(s.name)
  useEffect(() => setName(s.name), [s.name])
  const file = useRef<HTMLInputElement>(null)
  const [pending, setPending] = useState<any>(null), [pendingName, setPendingName] = useState(''), [reset, setReset] = useState(0), [typed, setTyped] = useState('')

  const numField = (label: string, key: keyof Settings, step = '1', unit = '') => (
    <Field label={label + (unit ? ` (${unit})` : '')}>
      <NumInput value={s[key] as number} step={step} onCommit={(v) => run(() => saveSettings({ [key]: v } as Partial<Settings>))} />
    </Field>
  )

  const exportJson = async () => {
    try { const b = await buildBackup(); download(`life-os-backup-${today()}.json`, JSON.stringify(b), 'application/json'); toast('Backup downloaded. Check your Downloads folder.') }
    catch (e) { toast('Backup failed: ' + (e as Error).message, 'err') }
  }
  const exportCsv = async () => {
    try { download(`life-os-transactions-${today()}.csv`, '\ufeff' + (await transactionsCsv()), 'text/csv'); toast('CSV downloaded') }
    catch (e) { toast('Export failed: ' + (e as Error).message, 'err') }
  }
  const pick = async (f?: File) => {
    if (!f) return
    try {
      if (f.size > 50 * 1024 * 1024) throw new Error('This file is too large to be a LIFE OS backup.')
      const obj = JSON.parse(await f.text())
      const err = validateBackup(obj)
      if (err) throw new Error(err)
      setPending(obj); setPendingName(f.name)
    } catch (e) { toast((e as Error).message.startsWith('Unexpected') ? 'That file is not valid JSON.' : (e as Error).message, 'err') }
    if (file.current) file.current.value = ''
  }

  return (
    <>
      <PageHead title="Settings" sub="Everything is saved on this device" />
      <div className="space-y-4">
        <Card>
          <Field label="Display name"><div className="flex gap-2"><input className="inp" value={name} onChange={(e) => setName(e.target.value)} /><Btn onClick={() => run(() => saveSettings({ name: name.trim() }), 'Saved')}>Save</Btn></div></Field>
          <Field label="Theme"><div className="grid grid-cols-2 gap-2">{(['dark', 'light'] as const).map((t) => <button key={t} onClick={() => run(() => saveSettings({ theme: t }))} className={`min-h-[48px] rounded-2xl font-semibold border ${s.theme === t ? 'bg-accent text-on border-accent' : 'border-line text-mute'}`}>{t === 'dark' ? 'Dark' : 'Light'}</button>)}</div></Field>
          <Field label="Currency"><select className="inp" value={s.currency} onChange={(e) => run(() => saveSettings({ currency: e.target.value }))}>{CURRENCIES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
        </Card>
        <Card><h3 className="font-bold mb-3">Study and sleep</h3>{numField('Daily study target', 'studyTargetMin', '5', 'minutes')}{numField('Sleep target', 'sleepTargetH', '0.5', 'hours')}</Card>
        <Card><h3 className="font-bold mb-3">Fitness targets</h3>{numField('Calories (estimate)', 'calorieTarget', '50', 'kcal')}{numField('Protein', 'proteinTarget', '5', 'g')}{numField('Water', 'waterTargetMl', '250', 'ml')}{numField('Steps', 'stepTarget', '500')}{numField('Workouts per week', 'weeklyWorkoutTarget')}{numField('Target weight (0 = none)', 'targetWeight', '0.5', 'kg')}</Card>

        <Card>
          <h3 className="font-bold mb-1">Backup and restore</h3>
          <p className="text-sm text-mute mb-4">Your data lives only in this browser on this phone. Clearing browser storage, clearing site data, or uninstalling the app can erase it. Export a backup regularly and keep the file somewhere safe, such as Google Drive.</p>
          <div className="space-y-3">
            <Btn full onClick={exportJson}><Download size={18} /> Export backup (JSON)</Btn>
            <Btn full variant="ghost" onClick={() => file.current?.click()}><Upload size={18} /> Import backup</Btn>
            <input ref={file} type="file" accept="application/json,.json" className="hidden" onChange={(e) => pick(e.target.files?.[0])} />
            <Btn full variant="ghost" onClick={exportCsv}><FileSpreadsheet size={18} /> Export transactions (CSV)</Btn>
          </div>
        </Card>

        <Card className="border-bad/40">
          <h3 className="font-bold mb-1 flex items-center gap-2 text-bad"><ShieldAlert size={18} /> Reset</h3>
          <p className="text-sm text-mute mb-3">Erases every record in LIFE OS on this device. Export a backup first.</p>
          <Btn full variant="danger" onClick={() => { setReset(1); setTyped('') }}><Trash2 size={18} /> Reset all data</Btn>
        </Card>

        <p className="text-xs text-mute text-center pb-4">LIFE OS 1.0 · No accounts, no tracking, no servers. Core screens work offline after the first load.</p>
      </div>

      {pending && (
        <Modal title="Replace your data?" onClose={() => setPending(null)}>
          <p className="text-mute mb-2">"{pendingName}" is a valid LIFE OS backup{pending.exportedAt ? ` from ${new Date(pending.exportedAt).toLocaleString()}` : ''}.</p>
          <p className="mb-5">Restoring will <b>replace all current data</b> in the app. This cannot be undone.</p>
          <div className="flex gap-3"><Btn variant="ghost" full onClick={() => setPending(null)}>Cancel</Btn><Btn variant="danger" full onClick={async () => { const ok = await run(() => restoreBackup(pending), 'Backup restored'); if (ok) setPending(null) }}>Replace data</Btn></div>
        </Modal>
      )}
      {reset === 1 && <Confirm text="This permanently deletes all your LIFE OS data on this device." yes="Continue" onNo={() => setReset(0)} onYes={() => setReset(2)} />}
      {reset === 2 && (
        <Modal title="Type RESET to confirm" onClose={() => setReset(0)}>
          <Field label="Type the word RESET"><input className="inp" value={typed} onChange={(e) => setTyped(e.target.value)} autoCapitalize="characters" autoFocus /></Field>
          <Btn full variant="danger" disabled={typed.trim().toUpperCase() !== 'RESET'} onClick={async () => { const ok = await run(() => resetAll(), 'All data erased'); if (ok) setReset(0) }}>Erase everything</Btn>
        </Modal>
      )}
    </>
  )
}

function NumInput({ value, step, onCommit }: { value: number; step: string; onCommit: (v: number) => void }) {
  const [v, setV] = useState(String(value))
  useEffect(() => setV(String(value)), [value])
  return <input className="inp num" type="number" inputMode="decimal" step={step} min={0} value={v} onChange={(e) => setV(e.target.value)} onBlur={() => { const n = Math.max(0, num(v)); if (n !== value) onCommit(n); else setV(String(value)) }} />
}

import { useEffect, useState } from 'react'
import { useLiveQuery } from 'dexie-react-hooks'
import { Pencil, Trash2, Plus, Minus } from 'lucide-react'
import { Bar, Btn, Card, Check, Confirm, Empty, Fab, Field, IconBtn, Loading, Modal, PageHead, Stat, Tabs, saveSettings, useRun, useSettings, useTabParam } from './ui'
import { db, type Daily, type Exercise, type Meal, type Workout } from './db'
import { addDays, dateLabel, lastDays, num, pct, today, weekStart } from './lib'
import { Bar as RBar, BarChart, CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'

const tip = { background: 'rgb(var(--panel2))', border: '1px solid rgb(var(--line))', borderRadius: 12 }
const axis = { fill: 'rgb(var(--mute))', fontSize: 11 }

export default function Fit() {
  const { tab, setTab, add, clearAdd } = useTabParam('today')
  return (
    <>
      <PageHead title="FitTrack" sub="Everything is entered by hand. No watch needed." />
      <Tabs value={tab} onChange={setTab} tabs={[{ id: 'today', label: 'Today' }, { id: 'weight', label: 'Weight' }, { id: 'meals', label: 'Meals' }, { id: 'workouts', label: 'Workouts' }]} />
      {tab === 'today' && <TodayTab />}
      {tab === 'weight' && <WeightTab autoAdd={add === '1'} clearAdd={clearAdd} />}
      {tab === 'meals' && <MealsTab autoAdd={add === '1'} clearAdd={clearAdd} />}
      {tab === 'workouts' && <WorkoutsTab />}
    </>
  )
}

/* ---------- Today ---------- */
function TodayTab() {
  const s = useSettings(), run = useRun(), t0 = today()
  const daily = useLiveQuery(() => db.daily.get(t0).then((d) => ({ d })), [])
  const meals = useLiveQuery(() => db.meals.where('date').equals(t0).toArray(), [])
  const workouts = useLiveQuery(() => db.workouts.where('date').equals(t0).toArray(), [])
  const [steps, setSteps] = useState(''), [act, setAct] = useState('')
  const d: Daily = daily?.d ?? { date: t0, waterMl: 0, steps: 0, activity: '' }
  useEffect(() => { setSteps(d.steps ? String(d.steps) : ''); setAct(d.activity) }, [daily?.d?.steps, daily?.d?.activity])
  if (!daily || !meals || !workouts) return <Loading />
  const kcal = meals.reduce((a, m) => a + m.kcal, 0), prot = meals.reduce((a, m) => a + m.protein, 0)
  const put = (p: Partial<Daily>) => run(() => db.daily.put({ ...d, ...p }))
  return (
    <div className="space-y-4">
      <Card>
        <div className="flex items-center justify-between mb-2"><h3 className="font-bold">Water</h3><span className="num text-sm text-mute">{d.waterMl} / {s.waterTargetMl} ml</span></div>
        <Bar value={d.waterMl} max={s.waterTargetMl} />
        <div className="grid grid-cols-3 gap-2 mt-3">
          <Btn small variant="soft" onClick={() => put({ waterMl: d.waterMl + 250 })}><Plus size={16} />250</Btn>
          <Btn small variant="soft" onClick={() => put({ waterMl: d.waterMl + 500 })}><Plus size={16} />500</Btn>
          <Btn small variant="ghost" onClick={() => put({ waterMl: Math.max(0, d.waterMl - 250) })}><Minus size={16} />250</Btn>
        </div>
      </Card>
      <Card>
        <div className="flex items-center justify-between mb-2"><h3 className="font-bold">Steps</h3><span className="num text-sm text-mute">target {s.stepTarget.toLocaleString()}</span></div>
        <div className="flex gap-2"><input className="inp num" inputMode="numeric" placeholder="Steps today" value={steps} onChange={(e) => setSteps(e.target.value)} /><Btn onClick={() => put({ steps: Math.round(num(steps)) })}>Save</Btn></div>
        <div className="mt-3"><Bar value={d.steps} max={s.stepTarget} /></div>
      </Card>
      <Card>
        <h3 className="font-bold mb-2">Activity note</h3>
        <div className="flex gap-2"><input className="inp" placeholder="e.g. 30 min walk" value={act} onChange={(e) => setAct(e.target.value)} /><Btn onClick={() => put({ activity: act.trim() })}>Save</Btn></div>
      </Card>
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Calories (estimate)" value={`${kcal}`} sub={`target ${s.calorieTarget}`} />
        <Stat label="Protein (estimate)" value={`${prot} g`} sub={`target ${s.proteinTarget} g`} />
        <Stat label="Workouts today" value={`${workouts.filter((w) => w.completed).length} / ${workouts.length}`} />
        <Stat label="Steps" value={d.steps.toLocaleString()} sub={`${pct(d.steps, s.stepTarget)}% of target`} />
      </div>
    </div>
  )
}

/* ---------- Weight ---------- */
function WeightTab({ autoAdd, clearAdd }: { autoAdd: boolean; clearAdd: () => void }) {
  const s = useSettings(), run = useRun()
  const rows = useLiveQuery(() => db.weights.orderBy('date').toArray(), [])
  const [kg, setKg] = useState(''), [date, setDate] = useState(today()), [tw, setTw] = useState(''), [del, setDel] = useState<number | null>(null)
  useEffect(() => setTw(s.targetWeight ? String(s.targetWeight) : ''), [s.targetWeight])
  useEffect(() => { if (autoAdd) clearAdd() }, [autoAdd])
  if (!rows) return <Loading />
  const first = rows[0], last = rows[rows.length - 1]
  const data = rows.map((r) => ({ d: r.date.slice(5), kg: r.kg }))
  return (
    <div className="space-y-4">
      <Card>
        <h3 className="font-bold mb-3">Log weight</h3>
        <div className="grid grid-cols-2 gap-3"><Field label="Weight (kg)"><input className="inp num" inputMode="decimal" value={kg} onChange={(e) => setKg(e.target.value)} autoFocus={autoAdd} /></Field><Field label="Date"><input type="date" className="inp" value={date} onChange={(e) => setDate(e.target.value || today())} /></Field></div>
        <Btn full onClick={async () => { const v = num(kg); if (v <= 0) return alert('Enter your weight in kg.'); if (await run(() => db.weights.add({ date, kg: v }), 'Weight saved')) setKg('') }}>Save weight</Btn>
      </Card>
      <Card>
        <Field label="Target weight (kg)"><div className="flex gap-2"><input className="inp num" inputMode="decimal" value={tw} onChange={(e) => setTw(e.target.value)} /><Btn variant="soft" onClick={() => run(() => saveSettings({ targetWeight: num(tw) }), 'Target saved')}>Set</Btn></div></Field>
      </Card>
      {rows.length === 0 ? <Empty title="No weight entries yet" text="Log your weight to see your trend." /> : (
        <>
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Current" value={`${last.kg} kg`} />
            <Stat label="Change" value={`${last.kg - first.kg > 0 ? '+' : ''}${(last.kg - first.kg).toFixed(1)}`} sub="since first entry" />
            <Stat label="To target" value={s.targetWeight ? `${(last.kg - s.targetWeight).toFixed(1)} kg` : '-'} />
          </div>
          <Card>
            <div style={{ height: 200 }}><ResponsiveContainer><LineChart data={data}>
              <CartesianGrid stroke="rgb(var(--line))" vertical={false} /><XAxis dataKey="d" tick={axis} axisLine={false} tickLine={false} /><YAxis domain={['dataMin - 2', 'dataMax + 2']} tick={axis} axisLine={false} tickLine={false} width={34} />
              <Tooltip contentStyle={tip} />{s.targetWeight > 0 && <ReferenceLine y={s.targetWeight} stroke="#f59e0b" strokeDasharray="4 4" />}
              <Line type="monotone" dataKey="kg" stroke="#2dd4a8" strokeWidth={3} dot={{ r: 3 }} />
            </LineChart></ResponsiveContainer></div>
          </Card>
          <ul className="space-y-2">{[...rows].reverse().slice(0, 30).map((r) => (
            <li key={r.id} className="rounded-2xl border border-line bg-panel p-3 flex items-center"><span className="flex-1">{dateLabel(r.date)}</span><span className="num font-bold mr-2">{r.kg} kg</span><IconBtn label="Delete" tone="bad" onClick={() => setDel(r.id!)}><Trash2 size={18} /></IconBtn></li>))}</ul>
        </>
      )}
      {del !== null && <Confirm text="Delete this weight entry?" onNo={() => setDel(null)} onYes={async () => { await run(() => db.weights.delete(del), 'Deleted'); setDel(null) }} />}
    </div>
  )
}

/* ---------- Meals ---------- */
function MealsTab({ autoAdd, clearAdd }: { autoAdd: boolean; clearAdd: () => void }) {
  const s = useSettings(), run = useRun()
  const [date, setDate] = useState(today()), [form, setForm] = useState<Meal | null>(null), [del, setDel] = useState<Meal | null>(null)
  const meals = useLiveQuery(() => db.meals.where('date').equals(date).toArray(), [date])
  useEffect(() => { if (autoAdd) { setForm({ date: today(), name: '', kcal: 0, protein: 0 }); clearAdd() } }, [autoAdd])
  if (!meals) return <Loading />
  const kcal = meals.reduce((a, m) => a + m.kcal, 0), prot = meals.reduce((a, m) => a + m.protein, 0)
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2"><Btn small variant="ghost" onClick={() => setDate(addDays(date, -1))}>‹</Btn><input type="date" className="inp text-center" value={date} onChange={(e) => setDate(e.target.value || today())} /><Btn small variant="ghost" onClick={() => setDate(addDays(date, 1))}>›</Btn></div>
      <Card>
        <div className="flex justify-between text-sm mb-1"><span>Calories (estimate)</span><span className="num text-mute">{kcal} / {s.calorieTarget}</span></div><Bar value={kcal} max={s.calorieTarget} />
        <div className="flex justify-between text-sm mt-3 mb-1"><span>Protein (estimate)</span><span className="num text-mute">{prot} / {s.proteinTarget} g</span></div><Bar value={prot} max={s.proteinTarget} color="#60a5fa" />
        <p className="text-xs text-mute mt-3">All nutrition numbers are your own estimates, not measured values.</p>
      </Card>
      {meals.length === 0 ? <Empty title="No meals logged" text="Add what you ate with a rough calorie and protein estimate." /> : (
        <ul className="space-y-2">{meals.map((m) => (
          <li key={m.id} className="rounded-2xl border border-line bg-panel p-3 flex items-center gap-2">
            <div className="flex-1 min-w-0"><p className="font-semibold truncate">{m.name}</p><p className="text-xs text-mute num">~{m.kcal} kcal · ~{m.protein} g protein</p></div>
            <IconBtn label="Edit" onClick={() => setForm(m)}><Pencil size={18} /></IconBtn><IconBtn label="Delete" tone="bad" onClick={() => setDel(m)}><Trash2 size={18} /></IconBtn>
          </li>))}</ul>
      )}
      <Fab label="Meal" onClick={() => setForm({ date, name: '', kcal: 0, protein: 0 })} />
      {form && <MealForm m={form} onClose={() => setForm(null)} />}
      {del && <Confirm text={`Delete "${del.name}"?`} onNo={() => setDel(null)} onYes={async () => { await run(() => db.meals.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}
function MealForm({ m, onClose }: { m: Meal; onClose: () => void }) {
  const run = useRun(), [f, setF] = useState(m), [k, setK] = useState(m.kcal ? String(m.kcal) : ''), [p, setP] = useState(m.protein ? String(m.protein) : '')
  return (
    <Modal title={f.id ? 'Edit meal' : 'Add meal'} onClose={onClose}>
      <Field label="What did you eat?"><input className="inp" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoFocus /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Calories (estimate)"><input className="inp num" inputMode="numeric" value={k} onChange={(e) => setK(e.target.value)} /></Field>
        <Field label="Protein g (estimate)"><input className="inp num" inputMode="decimal" value={p} onChange={(e) => setP(e.target.value)} /></Field>
      </div>
      <Field label="Date"><input type="date" className="inp" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value || today() })} /></Field>
      <Btn full onClick={async () => { if (!f.name.trim()) return alert('Name the meal.'); const rec = { ...f, name: f.name.trim(), kcal: Math.round(num(k)), protein: Math.round(num(p)) }; if (await run(() => (f.id ? db.meals.put(rec) : db.meals.add(rec)), 'Saved')) onClose() }}>Save</Btn>
    </Modal>
  )
}

/* ---------- Workouts ---------- */
function WorkoutsTab() {
  const s = useSettings(), run = useRun()
  const rows = useLiveQuery(() => db.workouts.orderBy('date').reverse().toArray(), [])
  const [form, setForm] = useState<Workout | null>(null), [del, setDel] = useState<Workout | null>(null)
  if (!rows) return <Loading />
  const ws = weekStart(today()), thisWeek = rows.filter((w) => w.completed && w.date >= ws).length
  const weeks = Array.from({ length: 8 }, (_, i) => { const st = addDays(ws, (i - 7) * 7); return { w: st.slice(5), n: rows.filter((r) => r.completed && r.date >= st && r.date < addDays(st, 7)).length } })
  const blank = (): Workout => ({ date: today(), name: '', completed: false, exercises: [{ name: '', sets: 3, reps: 10, weight: 0 }] })
  return (
    <div className="space-y-4">
      <Card><div className="flex justify-between text-sm mb-1"><span>This week</span><span className="num text-mute">{thisWeek} / {s.weeklyWorkoutTarget} workouts</span></div><Bar value={thisWeek} max={s.weeklyWorkoutTarget} /></Card>
      <Card><h3 className="font-bold mb-2">Completed workouts per week</h3>
        <div style={{ height: 150 }}><ResponsiveContainer><BarChart data={weeks}><XAxis dataKey="w" tick={axis} axisLine={false} tickLine={false} /><YAxis hide allowDecimals={false} /><Tooltip contentStyle={tip} cursor={{ fill: 'rgb(var(--panel2))' }} /><RBar dataKey="n" name="Workouts" fill="#2dd4a8" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div>
      </Card>
      {rows.length === 0 ? <Empty title="No workouts yet" text="Plan a workout with exercises, sets and reps, then tick it off when done." /> : (
        <ul className="space-y-2">{rows.slice(0, 40).map((w) => (
          <li key={w.id} className="rounded-2xl border border-line bg-panel p-3">
            <div className="flex items-center gap-3">
              <Check on={w.completed} label={`Mark ${w.name} complete`} onClick={() => run(() => db.workouts.put({ ...w, completed: !w.completed }))} />
              <div className="flex-1 min-w-0"><p className="font-semibold truncate">{w.name}</p><p className="text-xs text-mute">{dateLabel(w.date)}</p></div>
              <IconBtn label="Edit" onClick={() => setForm(w)}><Pencil size={18} /></IconBtn><IconBtn label="Delete" tone="bad" onClick={() => setDel(w)}><Trash2 size={18} /></IconBtn>
            </div>
            {w.exercises.length > 0 && <ul className="mt-2 pl-11 text-sm text-mute space-y-0.5">{w.exercises.map((e, i) => <li key={i} className="num">{e.name} — {e.sets} × {e.reps}{e.weight ? ` @ ${e.weight} kg` : ''}</li>)}</ul>}
          </li>))}</ul>
      )}
      <Fab label="Workout" onClick={() => setForm(blank())} />
      {form && <WorkoutForm w={form} onClose={() => setForm(null)} />}
      {del && <Confirm text={`Delete "${del.name}"?`} onNo={() => setDel(null)} onYes={async () => { await run(() => db.workouts.delete(del.id!), 'Deleted'); setDel(null) }} />}
    </div>
  )
}
function WorkoutForm({ w, onClose }: { w: Workout; onClose: () => void }) {
  const run = useRun(), [f, setF] = useState(w)
  const setEx = (i: number, p: Partial<Exercise>) => setF({ ...f, exercises: f.exercises.map((e, j) => (j === i ? { ...e, ...p } : e)) })
  return (
    <Modal title={f.id ? 'Edit workout' : 'New workout'} onClose={onClose}>
      <Field label="Workout name"><input className="inp" placeholder="e.g. Push day" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} autoFocus /></Field>
      <Field label="Date"><input type="date" className="inp" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value || today() })} /></Field>
      <p className="text-sm text-mute mb-2">Exercises</p>
      {f.exercises.map((e, i) => (
        <div key={i} className="rounded-2xl bg-panel2 p-3 mb-3">
          <div className="flex gap-2 mb-2"><input className="inp" placeholder="Exercise" aria-label="Exercise name" value={e.name} onChange={(x) => setEx(i, { name: x.target.value })} /><IconBtn label="Remove exercise" tone="bad" onClick={() => setF({ ...f, exercises: f.exercises.filter((_, j) => j !== i) })}><Trash2 size={18} /></IconBtn></div>
          <div className="grid grid-cols-3 gap-2">
            <label className="text-xs text-mute">Sets<input className="inp num" inputMode="numeric" value={e.sets || ''} onChange={(x) => setEx(i, { sets: Math.round(num(x.target.value)) })} /></label>
            <label className="text-xs text-mute">Reps<input className="inp num" inputMode="numeric" value={e.reps || ''} onChange={(x) => setEx(i, { reps: Math.round(num(x.target.value)) })} /></label>
            <label className="text-xs text-mute">Kg<input className="inp num" inputMode="decimal" value={e.weight || ''} onChange={(x) => setEx(i, { weight: num(x.target.value) })} /></label>
          </div>
        </div>))}
      <Btn variant="soft" small className="mb-4" onClick={() => setF({ ...f, exercises: [...f.exercises, { name: '', sets: 3, reps: 10, weight: 0 }] })}>+ Add exercise</Btn>
      <Btn full onClick={async () => { if (!f.name.trim()) return alert('Name the workout.'); const rec = { ...f, name: f.name.trim(), exercises: f.exercises.filter((e) => e.name.trim()) }; if (await run(() => (f.id ? db.workouts.put(rec) : db.workouts.add(rec)), 'Saved')) onClose() }}>Save workout</Btn>
    </Modal>
  )
}
